document.addEventListener("DOMContentLoaded", () => {
  const taskList = document.getElementById("task-list");
  const addTaskButton = document.getElementById("add-task");
  const searchInput = document.getElementById("search");

  let tasks = [];

  function fetchAndDisplayTasks() {
    fetch("/TaskManager/tasks")
      .then((response) => response.json())
      .then((data) => {
        tasks = data;
        displayTasks();
      })
      .catch((error) => console.error("Error fetching tasks:", error));
  }

  function displayTasks() {
    const tableHeaders = [
      "Id",
      "Description",
      "Assigned To",
      "Priority",
      "Deadline",
      "Status",
      "Category",
      "Estimated Time",
      "Notes",
      "Actions",
    ];

    taskList.innerHTML = "";

    const searchText = searchInput.value.toLowerCase();
    const filteredTasks = tasks.filter((task) => {
      return Object.values(task).some((detail) => {
        if (typeof detail === "string") {
          return detail.toLowerCase().includes(searchText);
        }
        return false;
      });
    });

    const table = document.createElement("table");
    table.classList.add("task-table");

    const headerRow = table.createTHead().insertRow();

    tableHeaders.forEach((headerText) => {
      const th = document.createElement("th");
      th.textContent = headerText;
      headerRow.appendChild(th);
    });

    const tbody = table.createTBody();
    filteredTasks.forEach((task) => {
      const row = tbody.insertRow();

      Object.keys(task).forEach((key) => {
        const cell = row.insertCell();
        cell.textContent = task[key];
        if (key === "priority") {
          cell.classList.add(getPriorityClass(task[key]));
        }
        if (key === "") {
          cell.classList.add(getPriorityClass(task[key]));
        }
      });

      const actionsCell = row.insertCell();
      const editButton = document.createElement("button");
      editButton.textContent = "Edit";
      editButton.classList.add("edit-button");
      editButton.addEventListener("click", () => openEditForm(task.id));

      const deleteButton = document.createElement("button");
      deleteButton.textContent = "Delete";
      deleteButton.addEventListener("click", () => deleteTask(task.id));

      actionsCell.appendChild(editButton);
      actionsCell.appendChild(deleteButton);
    });

    taskList.appendChild(table);
  }

  function getPriorityClass(priority) {
    switch (priority) {
      case "high":
        return "Priority-high";
      case "medium":
        return "Priority-medium";
      case "low":
        return "Priority-low";
      default:
        return "";
    }
  }
  function addTask() {
    const descriptionInput = document.getElementById("task-description");
    const assignedToInput = document.getElementById("assigned-to");
    const priorityInput = document.getElementById("priority");
    const deadlineInput = document.getElementById("deadline");
    const statusInput = document.getElementById("status");
    const categoryInputs = document.getElementsByName("category");
    const estimatedTimeInput = document.getElementById("estimated-time");
    const notesInput = document.getElementById("notes");

    const description = descriptionInput.value.trim();
    const assignedTo = assignedToInput.value.trim();
    const priority = priorityInput.value;
    const deadline = deadlineInput.value.trim();
    const status = statusInput.value;
    let category = "";
    categoryInputs.forEach((input) => {
      if (input.checked) {
        category = input.value;
      }
    });
    const estimatedTime = estimatedTimeInput.value.trim();
    const notes = notesInput.value.trim();

    // Validation for Task Description
    if (!isValidText(description)) {
      displayErrorMessage(
        descriptionInput,
        "Task Description can only contain letters, numbers, and spaces."
      );
      return;
    }

    // Validation for Assigned To
    if (!isValidText(assignedTo)) {
      displayErrorMessage(
        assignedToInput,
        "Assigned To can only contain letters, numbers, and spaces."
      );
      return;
    }

    // Validation for Deadline
    if (!isValidDate(deadline)) {
      displayErrorMessage(
        deadlineInput,
        "Please enter a valid date for the Deadline."
      );
      return;
    }

    // Validation for Estimated Time - should be a number
    if (!isValidEstimatedTime(estimatedTime)) {
      displayErrorMessage(
        estimatedTimeInput,
        "Estimated Time should be a number."
      );
      return;
    }

    const task = {
      id: Date.now(),
      description,
      assignedTo,
      priority,
      deadline,
      status,
      category,
      estimatedTime,
      notes,
    };
    // tasks.push(task);

    // Clear the form only if there were no errors
    clearForm();
    fetch("/TaskManager/tasks", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(task),
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error("Failed to add task");
        }
        return response.json();
      })
      .then((data) => {
        tasks.push(data);
        displayTasks();
        clearForm();
        localStorage.setItem("tasks", JSON.stringify(tasks));
      })
      .catch((error) => console.error("Error adding task:", error));
  }

  function isValidText(text) {
    const textRegex = /^[a-zA-Z0-9\s]+$/;
    return textRegex.test(text);
  }

  function isValidDate(date) {
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    return dateRegex.test(date);
  }

  function isValidEstimatedTime(estimatedTime) {
    const estimatedTimeRegex = /^\d+$/;
    return estimatedTimeRegex.test(estimatedTime);
  }

  function displayErrorMessage(inputElement, errorMessage) {
    const errorElement = document.createElement("div");
    errorElement.classList.add("error-message");
    errorElement.textContent = errorMessage;
    inputElement.parentNode.insertBefore(
      errorElement,
      inputElement.nextSibling
    );
  }

  function clearForm() {
    document.getElementById("task-form").reset();
  }

  function openEditForm(taskId) {
    window.location.href = `editTask.html?taskId=${taskId}`;
  }

  function deleteTask(taskId) {
    tasks = tasks.filter((task) => task.id !== taskId);
    localStorage.setItem("tasks", JSON.stringify(tasks));
    // displayTasks();
    fetch(`/TaskManager/tasks/${taskId}`, {
      method: "DELETE",
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error("Failed to delete task");
        }
        return response.json();
      })
      .then(() => {
        tasks = tasks.filter((task) => task.id !== taskId);
        // displayTasks();
      })
      .catch((error) => console.error("Error deleting task:", error));
  }

  addTaskButton.addEventListener("click", addTask);

  searchInput.addEventListener("input", displayTasks);

  fetchAndDisplayTasks();
});
