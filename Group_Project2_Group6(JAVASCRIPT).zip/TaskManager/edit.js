document.addEventListener("DOMContentLoaded", () => {
  const editForm = document.getElementById("edit-form");

  function getQueryParam(name) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(name);
  }

  const taskId = getQueryParam("taskId");

  let tasks = JSON.parse(localStorage.getItem("tasks")) || [];
  const taskIndex = tasks.findIndex((t) => t.id == taskId);
  let task = tasks[taskIndex];

  if (task) {
    document.getElementById("edit-description").value = task.description;
    document.getElementById("edit-assigned-to").value = task.assignedTo;
    document.getElementById("edit-priority").value = task.priority;
    document.getElementById("edit-deadline").value = task.deadline;
    document.getElementById("edit-status").value = task.status;
    document.querySelector(
      `input[name="edit-category"][value="${task.category}"]`
    ).checked = true;
    document.getElementById("edit-estimated-time").value = task.estimatedTime;
    document.getElementById("edit-notes").value = task.notes;
  }

  editForm.onsubmit = (e) => {
    e.preventDefault();
    if (task) {
      const description = document
        .getElementById("edit-description")
        .value.trim();
      const assignedTo = document
        .getElementById("edit-assigned-to")
        .value.trim();
      const priority = document.getElementById("edit-priority").value.trim();
      const deadline = document.getElementById("edit-deadline").value.trim();
      const status = document.getElementById("edit-status").value.trim();
      const category = document.querySelector(
        'input[name="edit-category"]:checked'
      ).value;
      const estimatedTime = document
        .getElementById("edit-estimated-time")
        .value.trim();
      const notes = document.getElementById("edit-notes").value.trim();

      if (
        !description ||
        !assignedTo ||
        !priority ||
        !deadline ||
        !status ||
        !category ||
        !estimatedTime ||
        !notes
      ) {
        alert("All fields are required.");
        return;
      }

      tasks[taskIndex] = {
        ...task,
        description,
        assignedTo,
        priority,
        deadline,
        status,
        category,
        estimatedTime,
        notes,
      };

      localStorage.setItem("tasks", JSON.stringify(tasks));
      window.location.href = "index.html";
    }
  };
});
