// server.js
const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const tasksFilePath = "tasks.json";

app.use(bodyParser.json());

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "TaskManager", "index.html"));
});
// Read all tasks
app.get("/tasks", (req, res) => {
  try {
    const tasks = JSON.parse(fs.readFileSync(tasksFilePath, "utf8"));
    res.json(tasks);
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
});

// Read a single task
app.get("/tasks/:id", (req, res) => {
  try {
    const taskId = req.params.id;
    const tasks = JSON.parse(fs.readFileSync(tasksFilePath, "utf8"));
    const task = tasks.find((task) => task.id == taskId);
    if (!task) {
      res.status(404).json({ error: "Task not found" });
      return;
    }
    res.json(task);
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
});

// Create a new task
app.post("/TaskManager/tasks", (req, res) => {
  try {
    const newTask = req.body;
    const tasks = JSON.parse(fs.readFileSync(tasksFilePath, "utf8"));
    newTask.id = Date.now();
    tasks.push(newTask);
    fs.writeFileSync(tasksFilePath, JSON.stringify(tasks, null, 2));
    res.status(201).json(newTask);
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
});

// Update a task
app.put("/TaskManager/tasks/:id", (req, res) => {
  try {
    console.log("hi update");
    const taskId = req.params.id;
    const updatedTask = req.body;
    const tasks = JSON.parse(fs.readFileSync(tasksFilePath, "utf8"));
    console.log("hi update");
    const index = tasks.findIndex((task) => task.id == taskId);
    if (index === -1) {
      res.status(404).json({ error: "Task not found" });
      return;
    }
    updatedTask.id = taskId;
    tasks[index] = updatedTask;
    fs.writeFileSync(tasksFilePath, JSON.stringify(tasks, null, 2));
    res.json(updatedTask);
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
});

// Delete a task
app.delete("/TaskManager/tasks/:id", (req, res) => {
  try {
    const taskId = req.params.id;
    const tasks = JSON.parse(fs.readFileSync(tasksFilePath, "utf8"));
    const filteredTasks = tasks.filter((task) => task.id != taskId);
    if (filteredTasks.length === tasks.length) {
      res.status(404).json({ error: "Task not found" });
      return;
    }
    fs.writeFileSync(tasksFilePath, JSON.stringify(filteredTasks, null, 2));
    res.json({ message: "Task deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
});

// Serve client-side UI
app.use(express.static(path.join(__dirname, "TaskManager")));

// Start server
app.listen(PORT, () => {
  console.log(
    `Server is running on port ${PORT} http://localhost:${PORT}/index.html`
  );
});
