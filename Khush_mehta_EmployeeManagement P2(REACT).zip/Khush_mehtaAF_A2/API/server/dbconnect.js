const { MongoClient, ObjectId } = require("mongodb");
const { GraphQLScalarType, Kind } = require("graphql");

const DB_URL = "mongodb+srv://Khush:Khush123@adfullstack.nkbdwsh.mongodb.net/";

let db = null;
let employeeDBCollection = null;

const connectToDB = async () => {
  const client = new MongoClient(DB_URL, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });

  await client.connect();
  console.log("Database connected successfully");
  db = client.db("AdFullstack");

  employeeDBCollection = db.collection("employees");

  // Ensure indexes are created
  await employeeDBCollection.createIndex({ emp_id: 1 }, { unique: true });
};

const DateScalar = new GraphQLScalarType({
  name: "Date",
  description: "Custom Date scalar type",
  serialize(value) {
    return value instanceof Date ? value.toISOString() : null;
  },
  parseValue(value) {
    return value ? new Date(value) : null;
  },
  parseLiteral(ast) {
    return ast.kind === Kind.STRING ? new Date(ast.value) : null;
  },
});

const getEmployeeDB = async (id) =>
  await employeeDBCollection.findOne({ _id: new ObjectId(id) })

const getEmployeesDB = async () => {
  return await employeeDBCollection.find().toArray();
};

const employeeDataUpdateDB = async (employee) => {
  const query = { _id: new ObjectId(employee._id) };

  const employeeDataUpdate = { ...employee };
  delete employeeDataUpdate._id;

  const update = { $set: employeeDataUpdate };

  try {
    if (employee._id) {
      const result = await employeeDBCollection.updateOne(query, update);
      if (result.matchedCount === 0) {
        throw new Error('No employee found with the given _id');
      }
      return result;
    } else {
      throw new Error('Employee ID is required');
    }
  } catch (error) {
    console.error('Error in employeeDataUpdateDB:', error);
    throw error;
  }
};

const addEmployeeDB = async (employee) => {
  return await employeeDBCollection.insertOne(employee);
};

const deleteEmployeeDB = async (id) =>
  await employeeDBCollection.deleteOne({ _id: new ObjectId(id) });

const SearchEmployeesDB = async (searchFilters) => {
  try {
    let query = {};

    if (searchFilters.employeeType) {
      query.employeeType = searchFilters.employeeType;
    }

    const searchedEmployees = await employeeDBCollection.find(query).toArray();
    return searchedEmployees;
  } catch (error) {
    console.error('Error in searchEmployees:', error);
    throw error;
  }
}

module.exports = {
  connectToDB,
  getEmployeesDB,
  addEmployeeDB,
  DateScalar,
  deleteEmployeeDB,
  employeeDataUpdateDB,
  getEmployeeDB,
  SearchEmployeesDB,
};
