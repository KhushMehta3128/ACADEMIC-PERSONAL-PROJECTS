require('dotenv').config();
const express = require("express");
const { ApolloServer, gql } = require("apollo-server-express");
const { GraphQLScalarType, Kind } = require("graphql");
const { uid } = require("uid");
const {
  getEmployeesDB,
  addEmployeeDB,
  connectToDB,
  deleteEmployeeDB,
  employeeDataUpdateDB,
  getEmployeeDB,
  SearchEmployeesDB,
} = require("./dbconnect");

let aboutMessage = "Welcome to the Employee Management System";

// GraphQL schema 
const typeDefs = gql`
  scalar Date

  type Employee {
    _id: ID!
    firstName: String!
    lastName: String!
    age: String!
    dateOfJoining: Date!
    title: String!
    department: String!
    employeeType: String!
    Currentstatus: Boolean!
    created: Date!
  }
    input EmployeeFilters{
    employeeType: String
    }

  type Query {
    about: String!
    listEmployees: [Employee!]!
    getEmployee(id: ID!): Employee!
    searchEmployees(filters: EmployeeFilters!): [Employee!]!
  }

  type Mutation {
    setAbout(message: String!): String
    addEmployee(employee: EmployeeInput!): Employee!
    deleteEmployee(id: ID!): String
    employeeDataUpdate(employee: EmployeeEditInput!): Employee!
  }

  input EmployeeInput {
    firstName: String!
    lastName: String!
    age: String!
    dateOfJoining: Date!
    title: String!
    department: String!
    employeeType: String!
  }

  input EmployeeEditInput {
    title: String
    department: String!
    Currentstatus: Int!
    _id: ID!
  }
`;

// Custom Date scalar 
const DateScalar = new GraphQLScalarType({
  name: "Date",
  description: "Custom Date scalar type",
  serialize(value) {
    return value instanceof Date ? value.toISOString() : null;
  },
  parseValue(value) {
    return value ? new Date(value) : null;
  },
  parseLiteral(ast) {
    return ast.kind === Kind.STRING ? new Date(ast.value) : null;
  },
});

// Function to validate employee input against predefined values
const validateEmployeeInput = (employee) => {
  const titles = ["Employee", "Manager", "Director", "VP"];
  const departments = ["IT", "Marketing", "HR", "Engineering"];
  const employeeTypes = ["FullTime", "PartTime", "Contract", "Seasonal"];
  const { age, title, department, employeeType } = employee;

  if (age < 20 || age > 70) throw new Error("Age must be between 20 and 70.");
  if (!titles.includes(title)) throw new Error("Invalid title.");
  if (!departments.includes(department)) throw new Error("Invalid department.");
  if (!employeeTypes.includes(employeeType)) throw new Error("Invalid employee type.");
};

const deleteEmployee = async (_, { id }) => {
  console.log('Deleting employee with id:', id);
  const result = await deleteEmployeeDB(id);
  if (result.deletedCount === 1) {
    return `Employee with id ${id} deleted successfully`;
  } else {
    throw new Error(`Failed to delete employee with id ${id}`);
  }
};

const employeeDataUpdate = async (_, { employee }) => {
  const { title, department, Currentstatus, _id } = employee;


  const employeeDataUpdate = {
    title,
    department,
    Currentstatus: parseInt(Currentstatus, 10),
    _id
  };

  const result = await employeeDataUpdateDB(employeeDataUpdate);

  if (result.matchedCount > 0) {
    return await getEmployeeDB(_id);
  } else {
    throw new Error('Failed to update employee');
  }
};

const searchEmployees = async (_, { filters }) => SearchEmployeesDB(filters);

// Resolvers define the implementation of the GraphQL schema
const resolvers = {
  Date: DateScalar,
  Query: {
    about: () => aboutMessage,
    listEmployees: async () => await getEmployeesDB(),
    getEmployee: async (_, { id }) => await getEmployeeDB(id),
    searchEmployees,
  },
  Mutation: {
    setAbout: (_, { message }) => {
      aboutMessage = message;
      return aboutMessage;
    },
    addEmployee: async (_, { employee }) => {
      // Resolver to add a new employee
      console.log({ employee });

      const newEmployee = {
        ...employee,
        emp_id: uid(8),
        dateOfJoining: new Date(employee.dateOfJoining),
        created: new Date(),
        Currentstatus: true,
        age: Number(employee.age)
      };
      const result = await addEmployeeDB(newEmployee);

      console.log({ result });
      try {
        if (result.acknowledged) {
          return newEmployee; // Return newly added employee on success
        }

      } catch (error) {
        throw new Error("Failed to add employee. ", error);

      }

    },
    deleteEmployee,
    employeeDataUpdate,
  },
};

const app = express();
const server = new ApolloServer({ typeDefs, resolvers }); // Create Apollo Server instance

const startServer = async () => {
  await server.start();
  await connectToDB();
  server.applyMiddleware({ app, path: "/graphql" });  // Apply Apollo Server middleware to Express app
};

startServer();

const PORT = process.env.SERVER_PORT

app.listen(PORT, () => {
  console.log(`server is running on http://localhost:${PORT}`);
});
