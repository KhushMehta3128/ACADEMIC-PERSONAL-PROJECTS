const path = require("path");
module.exports = {
  entry: { app: ["./jsx/App.jsx"] },
  output: {
    filename: "[name].bundle.js",
    path: path.resolve(__dirname, "public"),
  },
  mode: "development",
  module: {
    rules: [
      {
        test: /\.jsx?$/,
        exclude: /node_modules/,
        use: "babel-loader",
      },
    ],
  },

  resolve: {
    extensions: ['.js', '.jsx'],
  },

  optimization: {
    splitChunks: {
      name: "vendor",
      chunks: "all",
    },
  },

  devServer: {
    contentBase: "./",
    historyApiFallback: true,
    hot: true,
  },
};