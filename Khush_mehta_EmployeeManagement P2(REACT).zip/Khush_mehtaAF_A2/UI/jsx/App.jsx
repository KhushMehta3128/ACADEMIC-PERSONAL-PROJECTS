import React from 'react';
import ReactDOM from 'react-dom';
import EmployeeSearch from './Components/EmployeeSearch.jsx';
import EmployeeTable from './Components/EmployeeTable.jsx';
import EmployeeCreate from './Components/EmployeeCreate.jsx';
import constants from './constants';
import Page from './Page.jsx';
import { BrowserRouter as Router } from 'react-router-dom';
const { API_URL, pageStyle, ErrorStyle, buttonStyle } = constants;

class App extends React.Component {
  render() {
    return (
      <Router>
        <Page />
      </Router>
    );
  }
}

ReactDOM.render(<App />, document.getElementById('contents'));
