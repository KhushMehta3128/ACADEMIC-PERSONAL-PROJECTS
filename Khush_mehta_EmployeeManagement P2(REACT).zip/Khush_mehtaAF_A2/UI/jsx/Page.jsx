import React, { Component } from 'react';
import NavPage from './Components/NavBar.jsx';
import Routes from './Routes.jsx';


class Page extends Component {
  render() {
    return (
      <>
        <NavPage />
        <Routes />
      </>
    );
  }
}

export default Page;