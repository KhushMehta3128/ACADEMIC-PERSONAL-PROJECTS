import React from 'react';
import constants from '../constants/index.js';
const { API_URL, formStyle, inputStyle,
  buttonStyle } = constants;

const defaultState = {
  employee: {
    firstName: '',
    lastName: '',
    age: '',
    dateOfJoining: '',
    title: '',
    department: '',
    employeeType: '',
    Currentstatus: '',
  },
  errors: '',
};

class EmployeeEdit extends React.Component {
  constructor(props) {
    super(props);
    this.state = { ...defaultState };

    this.handleSubmit = this.handleSubmit.bind(this);
    this.editEmployee = this.editEmployee.bind(this);

    this.handleChange = (e) => {
      const { name, value } = e.target;
      this.setState((prevState) => ({
        employee: {
          ...prevState.employee,
          [name]: value,
        },
      }));
    };
  }

  async getData(employeeID) {
    const query = `query {
      getEmployee(id: "${employeeID}") {
        _id
        firstName
        lastName
        age
        dateOfJoining
        title
        department
        employeeType
        Currentstatus
      }
    }`;

    const response = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query }),
    });

    const result = await response.json();

    if (result.errors) {
      alert(result.errors[0].message);
    } else {
      this.setState({
        employee: {
          ...result.data.getEmployee,
          DateOfJoining:
            new Date(
              result.data.getEmployee.DateOfJoining
            )?.toDateString() || new Date()?.toDateString(),
        },
      });
    }
  }

  handleSubmit(e) {
    e.preventDefault();

    const employee = { ...this.state.employee };

    this.editEmployee(employee);
  }

  async editEmployee(employee) {
    const query = `
      mutation employeeDataUpdate($employee: EmployeeEditInput!) {
        employeeDataUpdate(employee: $employee) {
          title
department
Currentstatus
_id
        }
    }
    `;

    const employeeDataUpdate = {
      _id: employee._id,
      title: employee.title,
      department: employee.department,
      Currentstatus: parseInt(employee.Currentstatus, 10),
    };

    const response = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        query,
        variables: { employee: employeeDataUpdate },
      }),
    });

    const result = await response.json();
    console.log({ result });
    if (result.errors) {
      alert(result.errors[0].message);
    } else {
      this.props.history.push('/');
    }
  }

  componentDidMount() {
    const editID = this.props?.match?.params?.id;
    if (editID) {
      this.getData(editID);
    } else {
      this.props.history.push('/');
    }
  }

  render() {
    const { employee } = this.state;

    if (Object.keys(employee).length) {
      return (
        <div>
          <form
            name='employeeAdd'
            onSubmit={this.handleSubmit}
            style={formStyle}
          >
            <input
              type='text'
              name='firstName'
              placeholder='First Name'
              value={employee.firstName}
              style={inputStyle}
              disabled
            />
            <input
              type='text'
              name='lastName'
              placeholder='Last Name'
              value={employee.lastName}
              style={inputStyle}
              disabled
            />
            <input
              type='number'
              name='age'
              value={employee.age}
              placeholder='Age'
              style={inputStyle}
              disabled
            />
            <input
              type='text'
              placeholder='Date of Joining'
              name='dateOfJoining'
              value={employee.dateOfJoining}
              style={inputStyle}
              disabled
            />
            <select
              name='title'
              style={inputStyle}
              value={employee.title}
              onChange={this.handleChange}
            >
              <option value=''>Select Title</option>
              <option value='Employee'>Employee</option>
              <option value='Manager'>Manager</option>
              <option value="Director">Director</option>
              <option value="VP">VP</option>
            </select>
            <select
              name='department'
              value={employee.department}
              style={inputStyle}
              onChange={this.handleChange}
            >
              <option value=''>Select Department</option>
              <option value='IT'>IT</option>
              <option value='Marketing'>Marketing</option>
              <option value='HR'>HR</option>
              <option value='Engineering'>Engineering</option>
            </select>
            <select
              name='employeeType'
              value={employee.employeeType}
              style={inputStyle}
              onChange={this.handleChange}
              disabled
            >
              <option value=''>Select Employee Type</option>
              <option value='FullTime'>Full Time</option>
              <option value='PartTime'>Part Time</option>
              <option value="Contract">Contract</option>
              <option value="Seasonal">Seasonal</option>
            </select>
            {console.log(employee.Currentstatus)
            }<select
              name='Currentstatus'
              value={employee.Currentstatus}
              style={inputStyle}
              onChange={this.handleChange}
            >
              <option value=''>Status</option>
              <option value={1}>Working</option>
              <option value={0}>Retired</option>
            </select>
            <input
              type='submit'
              value='Update Employee'
              style={buttonStyle}
            />
          </form>
        </div>
      );
    } else {
      return <div>Please Wait</div>;
    }
  }
}

export default EmployeeEdit;