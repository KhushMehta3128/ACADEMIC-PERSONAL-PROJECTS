import React from 'react';
import constants from '../constants/index.js'
const { searchBox, submitButtonStyle, selectStyle, API_URL } = constants;
class EmployeeSearch extends React.Component {
  constructor(props) {
    super(props);
    this.handleChange = async (filterName, value) => {
      const filters = {
        [filterName]: value,
      };
      if (filters.employeeType) {
        const query = `
      query searchEmployees($filters: EmployeeFilters!) {
        searchEmployees(filters: $filters) {
       _id
       firstName
       lastName
       age
       dateOfJoining
       title
       department
       employeeType
       Currentstatus
        }
      }
    `;

        try {
          const response = await fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              query,
              variables: { filters },
            }),
          });

          const result = await response.json();

          if (result.errors) {
            this.setState({ errors: result.errors });
          } else {
            this.props.searchEmployees([...result.data.searchEmployees]);
          }
        } catch (error) {
          console.error('Error fetching filtered employees:', error);
          this.setState({ errors: [error.message] });
        }
      } else {
        this.props.loaddata();
      }
    };
  }

  render() {
    return (
      <>
        <div style={searchBox}>
          <select
            className="form-control"
            name="employeeType"
            onChange={(e) => this.handleChange(e.target.name, e.target.value)}
            required
            style={selectStyle}
          >
            <option value="">Search by Employee Type</option>
            <option value="FullTime">Full Time</option>
            <option value="PartTime">Part Time</option>
            <option value="Contract">Contract</option>
            <option value="Seasonal">Seasonal</option>
          </select>
        </div>
      </>
    );
  }
}

export default EmployeeSearch;