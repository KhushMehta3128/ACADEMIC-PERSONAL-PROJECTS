import React, { Component } from 'react'
import constants from '../constants/index.js'
const { formStyle, inputStyle, labelStyle, selectStyle, buttonStyle, API_URL } = constants;

export class EmployeeCreate extends Component {
    constructor(props) {
        super(props);
        this.state = {
          formData: {
            firstName: '',
            lastName: '',
            age: '',
            dateOfJoining: '',
            title: '',
            department: '',
            employeeType: ''
          }
        }

        this.handleChange = e => {
            const { name, value } = e.target;
            this.setState(prevState => ({
              formData: {
                ...prevState.formData,
                [name]: value
              }
            }));
          };

        this.handleSubmit = async e => {
            e.preventDefault();
            try {
              const { formData } = this.state;
              const response = await fetch(API_URL, {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                  query: `
                    mutation ($employee: EmployeeInput!) {
                      addEmployee(employee: $employee) {
                        _id
                        firstName
                        lastName
                        age
                        dateOfJoining
                        title
                        department
                        employeeType
                        Currentstatus
                      }
                    }
                  `,
                  variables: {
                    employee: this.state.formData
                  }
                })
              });
              const result = await response.json();
                            this.props.handleAddEmployee();
            } catch (error) {
              console.error("Error adding employee:", error);
            }
          };
    }
  render() {
    return (
        <div style={formStyle}>
        <h2>Create New Employee</h2>
        <form onSubmit={this.handleSubmit}>
          
          <div style={formStyle}>
            <label style={labelStyle}>First Name</label>
            <input
              type="text"
              className="form-control"
              name="firstName"
              value={this.state.formData.firstName}
              onChange={this.handleChange}
              required
              style={inputStyle}
            />
          </div>
          <div style={formStyle}>
            <label style={labelStyle}>Last Name</label>
            <input
              type="text"
              className="form-control"
              name="lastName"
              value={this.state.formData.lastName}
              onChange={this.handleChange}
              required
              style={inputStyle}
            />
          </div>
          <div style={formStyle}>
            <label style={labelStyle}>Age</label>
            <input
              type="number"
              className="form-control"
              name="age"
              value={this.state.formData.age}
              onChange={this.handleChange}
              required
              min="20"
              max="70"
              style={inputStyle}
            />
          </div>
          <div style={formStyle}>
            <label style={labelStyle}>Date of Joining</label>
            <input
              type="date"
              className="form-control"
              name="dateOfJoining"
              value={this.state.formData.dateOfJoining}
              onChange={this.handleChange}
              required
              style={inputStyle}
            />
          </div>
          <div style={formStyle}>
            <label style={labelStyle}>Title</label>
            <select
              className="form-control"
              name="title"
              value={this.state.formData.title}
              onChange={this.handleChange}
              required
              style={selectStyle}
            >
              <option value="">Select Title</option>
              <option value="Employee">Employee</option>
              <option value="Manager">Manager</option>
              <option value="Director">Director</option>
              <option value="VP">VP</option>
            </select>
          </div>
          <div style={formStyle}>
            <label style={labelStyle}>Department</label>
            <select
              className="form-control"
              name="department"
              value={this.state.formData.department}
              onChange={this.handleChange}
              required
              style={selectStyle}
            >
              <option value="">Select Department</option>
              <option value="IT">IT</option>
              <option value="Marketing">Marketing</option>
              <option value="HR">HR</option>
              <option value="Engineering">Engineering</option>
            </select>
          </div>
          <div style={formStyle}>
            <label style={labelStyle}>Employee Type</label>
            <select
              className="form-control"
              name="employeeType"
              value={this.state.formData.employeeType}
              onChange={this.handleChange}
              required
              style={selectStyle}
            >
              <option value="">Select Employee Type</option>
              <option value="FullTime">Full Time</option>
              <option value="PartTime">Part Time</option>
              <option value="Contract">Contract</option>
              <option value="Seasonal">Seasonal</option>
            </select>
          </div>
          <button type="submit" style={buttonStyle}>
            Submit
          </button>
        </form>
      </div>
    )
  }
}

export default EmployeeCreate