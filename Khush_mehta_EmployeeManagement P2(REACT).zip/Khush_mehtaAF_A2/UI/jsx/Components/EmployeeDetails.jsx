import React, { Component } from 'react'
import constants from '../constants';
const { API_URL, employeeDetailsStyle, employeeDetailsHeaderStyle, attributeStyle, attributeLastStyle, labelStyle, valueStyle } = constants;



const defaultState = {
    employee: {
        _id: "",
        firstName: "",
        lastName: "",
        age: "",
        dateOfJoining: "",
        title: "",
        department: "",
        employeeType: "",
        Currentstatus: "",
    },
    loading: true,
}

export class EmployeeDetails extends Component {
    constructor(props) {
        super(props);
        this.state = { ...defaultState };
        this.getdata = async (employeeID = this.props?.match?.params?.id) => {
            const query = `query {
              getEmployee(id: "${employeeID}") {
                _id
                firstName
                lastName
                age
                dateOfJoining
                title
                department
                employeeType
                Currentstatus
              }
            }`;

            const response = await fetch(API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ query }),
            });

            const result = await response.json();

            if (result.errors) {
                alert(result.errors[0].message);
            } else {

                this.setState({
                    employee: {
                        ...result.data.getEmployee,
                        dateOfJoining:
                            new Date(
                                result.data.getEmployee.dateOfJoining
                            )?.toDateString() || new Date()?.toDateString(),

                        Currentstatus: result.data.getEmployee.Currentstatus === true || result.data.getEmployee.Currentstatus === 1 ? "Working" : "Retired",
                    },
                    loading: false,
                });
            }
        }

    }

    componentDidMount() {
        const editID = this.props?.match?.params?.id;

        if (editID) {

            this.getdata(editID);
        } else {
            this.props.history.push('/');
        }
    }

    render() {
        const { employee } = this.state;
        const keys = ["firstName",
            "lastName",
            "age",
            "dateOfJoining",
            "title",
            "department",
            "employeeType",
            "Currentstatus"]
        console.log({ employee })
        if (this.state.loading) {
            return (
                <div>Loading...</div>)
        }
        else {
            return (
                <div style={employeeDetailsStyle}>
                    <h2 style={employeeDetailsHeaderStyle}>Employee Details</h2>
                    {keys.map((attr, index) => (
                        <div key={attr} style={index === keys.length - 1 ? { ...attributeStyle, ...attributeLastStyle } : attributeStyle}>
                            <div style={labelStyle}>{attr}:</div>
                            <div style={valueStyle}>{employee[attr]}</div>
                        </div>
                    ))}
                </div>
            );
        }
    }
}
export default EmployeeDetails