import React, { Component } from 'react'

export class NotFound extends Component {
  render() {
    return (
      <div>NotFound</div>
    )
  }
}

export default NotFound