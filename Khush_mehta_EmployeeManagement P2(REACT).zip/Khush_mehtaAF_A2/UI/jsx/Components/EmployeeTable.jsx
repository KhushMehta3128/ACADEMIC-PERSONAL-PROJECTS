import React, { Component } from 'react'
import constants from '../constants/index.js'
import { Link, withRouter } from 'react-router-dom';
const { tableStyle, thStyle, nameStyle, tdStyle, tdButtonStyle, buttonStyle, API_URL } = constants;

class EmployeeTable extends Component {
  constructor(props) {
    super(props);
    this.handleEdit = this.handleEdit.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
  }

  handleEdit(employee) {
    this.props.history.push(`/employee/edit/${employee._id}`);

  }

  async handleDelete(employee) {
    if (window.confirm('Are you sure you want to delete this employee?')) {
      const mutation = `
          mutation {
          deleteEmployee(id: "${employee._id}")}`;

      try {
        const response = await fetch(API_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ query: mutation }),
        });

        const result = await response.json();

        if (result.errors) {
          console.error('GraphQL error:', result.errors);
        } else {
          console.log({ result });
          this.props.refresh();
        }
      } catch (error) {
        console.error('Error deleting employee:', error);
      }
    }
  }

  render() {
    const { employees } = this.props;
    return (
      <table style={tableStyle}>
        <thead>
          <tr>
            <th style={thStyle}>#</th>
            <th style={thStyle}>Name</th>
            <th style={thStyle}>Age</th>
            <th style={thStyle}>Date of Joining</th>
            <th style={thStyle}>Title</th>
            <th style={thStyle}>Department</th>
            <th style={thStyle}>Employee Type</th>
            <th style={thStyle}>Currentstatus</th>
            <th style={thStyle}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {/* Map through employees and render each row */}
          {employees.map((employee, index) => (
            <tr key={employee._id}>
              <td style={tdStyle}>{index + 1}</td>
              <td style={tdStyle}>
                <Link style={nameStyle} to={`/employee/${employee._id}`}>
                  {`${employee.firstName} ${employee.lastName}`}
                </Link>
              </td>
              <td style={tdStyle}>{employee.age}</td>
              <td style={tdStyle}>{new Date(employee.dateOfJoining).toLocaleDateString()}</td>
              <td style={tdStyle}>{employee.title}</td>
              <td style={tdStyle}>{employee.department}</td>
              <td style={tdStyle}>{employee.employeeType}</td>
              <td style={tdStyle}>{employee.Currentstatus ? 'Working' : 'Retired'}</td>
              <td style={tdButtonStyle}>
                <button onClick={() => this.handleEdit(employee)} style={buttonStyle}>Edit</button>
                <button onClick={() => this.handleDelete(employee)} style={buttonStyle}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    )
  }
}

export default withRouter(EmployeeTable)