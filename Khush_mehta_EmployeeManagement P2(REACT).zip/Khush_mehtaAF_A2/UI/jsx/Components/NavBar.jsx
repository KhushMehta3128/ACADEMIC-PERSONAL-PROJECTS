import React, { Component } from 'react'
import { NavLink } from 'react-router-dom'

const navbarStyles = {
  ul: {
    listStyle: 'none',
    display: 'flex',
    justifyContent: 'flex-end',
    margin: 0,
    padding: 0,
  },
  li: {
    marginLeft: '20px',
  },
  link: {
    textDecoration: 'none',
    color: '#333',
    padding: '10px 15px',
    transition: 'color 0.3s ease',
  },
  linkHover: {
    color: '#007bff',
  },
  linkActive: {
    fontWeight: 'bold',
    color: '#007bff',
  },
};

export class NavPage extends Component {
  render() {
    return (
      <ul style={navbarStyles.ul}>
        <li style={navbarStyles.li}>
          <NavLink style={navbarStyles.link} activeStyle={navbarStyles.linkActive} exact to='/'> Home </NavLink>
        </li>
        <li style={navbarStyles.li}>
          <NavLink style={navbarStyles.link} activeStyle={navbarStyles.linkActive} exact to='/add-employee'> Add Employees </NavLink>
        </li>
      </ul >
    )
  }
}

export default NavPage