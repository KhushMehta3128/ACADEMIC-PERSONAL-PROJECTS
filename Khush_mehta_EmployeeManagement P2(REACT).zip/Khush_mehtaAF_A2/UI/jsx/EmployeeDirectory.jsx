import React from 'react';
import ReactDOM from 'react-dom';
import EmployeeSearch from './Components/EmployeeSearch.jsx';
import EmployeeTable from './Components/EmployeeTable.jsx';
import EmployeeCreate from './Components/EmployeeCreate.jsx';
import constants from './constants/index.js';
const { API_URL, pageStyle, ErrorStyle, buttonStyle } = constants;
class EmployeeDirectory extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      employees: [],
      displayAddedEmployee: false,
      formData: {
        firstName: '',
        lastName: '',
        age: '',
        dateOfJoining: '',
        title: '',
        department: '',
        employeeType: ''
      }, errors: [], searchedEmployees: []
    };
  }

  // Fetch employees data from the server when the component mounts
  componentDidMount() {
    this.employeeSearch();
  }

  // Function to fetch employees data from GraphQL server
  employeeSearch = async () => {
    try {
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          query: `
            query {
              listEmployees {
                _id
                firstName
                lastName
                age
                dateOfJoining
                title
                department
                employeeType
                Currentstatus
              }
            }
          `
        })
      });
      const result = await response.json();


      // Update state with fetched employees data
      this.setState({
        employees: result.data.listEmployees
      });
    } catch (error) {
      console.error("Error fetching employees:", error);
    }
  };



  // Toggle the visibility of the add employee form
  handleAddEmployee = () => {
    this.setState(prevState => ({
      displayAddedEmployee: !prevState.displayAddedEmployee
    }))
    this.employeeSearch()
  }



  render() {
    const { employees, displayAddedEmployee, formData } = this.state;
    return (
      <div style={pageStyle}>
        <h1>Employees</h1>
        {/* Display message when no employees are added */}
        {employees.length === 0 && (
          <p style={ErrorStyle}>No employees added yet.</p>
        )}
        {/* Search bar */}
        <EmployeeSearch searchEmployees={(emps) => this.setState({ ...this.state, employees: [...emps], })} loaddata={this.employeeSearch} />

        {/* Render table if there are employees */}
        <EmployeeTable employees={employees}
          errors={this.state.errors}
          refresh={this.employeeSearch} />
        {/* Button to toggle add employee form */}
        <button type="button" onClick={this.handleAddEmployee} style={buttonStyle}>
          {displayAddedEmployee ? 'Close' : 'Add Employee'}
        </button>
        {/* Render add employee form if displayAddedEmployee is true */}
        {displayAddedEmployee && (
          <EmployeeCreate handleAddEmployee={this.handleAddEmployee} />
        )}
      </div>
    );
  }
}
export default EmployeeDirectory

