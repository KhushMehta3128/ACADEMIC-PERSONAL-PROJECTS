

export default {
  API_URL: "http://localhost:4000/graphql",
  pageStyle: {
    borderRadius: '8px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    padding: '20px',
    margin: '20px auto',
    backgroundColor: '#ffffff',
    maxWidth: '800px',
  },

  tableStyle: {
    width: '100%',
    borderCollapse: 'collapse',
    marginTop: '20px',
  },

  thStyle: {
    backgroundColor: '#f0f0f0',
    borderBottom: '1px solid #dddddd',
    padding: '10px',
    textAlign: 'left',
  },

  tdStyle: {
    borderBottom: '1px solid #dddddd',
    padding: '10px',
  },

  tdButtonStyle: {
    display: 'flex',
    margin: '10px',
  },

  ErrorStyle: {
    color: 'red',
  },

  formStyle: {
    maxWidth: '400px',
    margin: '20px auto',
  },

  labelStyle: {
    display: 'block',
    marginBottom: '5px',
    fontWeight: 'bold',
  },

  nameStyle: {
    textDecoration: 'none',
    color: '#333',
  },

  inputStyle: {
    width: '100%',
    padding: '8px',
    margin: '8px 0',
    boxSizing: 'border-box',
    borderRadius: '4px',
    border: '1px solid #ccc',
  },

  selectStyle: {
    width: '100%',
    padding: '8px',
    margin: '8px 0',
    boxSizing: 'border-box',
    borderRadius: '4px',
    border: '1px solid #ccc',
  },

  buttonStyle: {
    padding: '10px 20px',
    borderRadius: '5px',
    backgroundColor: '#007bff',
    color: '#ffffff',
    border: 'none',
    cursor: 'pointer',
    marginRight: '10px',
  },

  employeeDetailsStyle: {
    maxWidth: '600px',
    margin: '20px auto',
    padding: '20px',
    border: '1px solid #ccc',
    borderRadius: '10px',
    backgroundColor: '#f9f9f9',
    boxShadow: '0 2px 5px rgba(0, 0, 0, 0.1)',
  },

  employeeDetailsHeaderStyle: {
    textAlign: 'center',
    marginBottom: '20px',
    color: '#333',
  },

  attributeStyle: {
    display: 'flex',
    justifyContent: 'space-between',
    marginBottom: '10px',
    padding: '10px',
    borderBottom: '1px solid #eaeaea',
  },

  attributeLastStyle: {
    borderBottom: 'none',
  },

  labelStyle: {
    fontWeight: 'bold',
    color: '#555',
  },

  valueStyle: {
    color: '#777',
  },
};