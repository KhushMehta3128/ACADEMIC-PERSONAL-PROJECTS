import React, { Component } from 'react';
import { Route, Switch } from 'react-router-dom';
import EmployeeDirectory from './EmployeeDirectory';
import EmployeeCreate from './Components/EmployeeCreate';
import NotFound from './Components/NotFound';
import EmployeeEdit from './Components/EmployeeEdit';
import EmployeeDetails from './Components/EmployeeDetails';

export class Routes extends Component {
  render() {
    return (
      <Switch>
        <Route exact path='/' component={EmployeeDirectory} />
        <Route exact path='/add-employee' component={EmployeeCreate} />
        <Route exact path='/employee/:id' component={EmployeeDetails}/>
        <Route exact path='/employee/edit/:id' component={EmployeeEdit}/>
        <Route component={NotFound}/>
      </Switch>
    )
  }
}

export default Routes