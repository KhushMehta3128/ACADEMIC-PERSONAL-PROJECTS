require('dotenv').config();
const express = require("express");



const app = express();

const PORT = process.env.SERVER_PORT

const enableHMR = process.env.ENABLE_HMR || "true" === "true";

const webpack = require("webpack");
const devMiddle = require("webpack-dev-middleware");
const hotMiddle = require("webpack-hot-middleware");
const config = require("../webpack.config.js");

if(enableHMR&&process.env.NODE_ENV !== "production"){
  config.entry.app.push('webpack-hot-middleware/client');
  config.plugins = [];
  config.plugins.push(new webpack.HotModuleReplacementPlugin());
  const compiler = webpack(config);
  app.use(
    devMiddle(compiler, {
      publicPath: config.output.publicPath,
      writeToDisk: true,
      noInfo: true,
      stats: { colors: true },
      hot: true,
      inline: true,
      lazy: false,
      headers: { 'Access-Control-Allow-Origin': '*' },
      historyApiFallback: true,
    })
  );

  app.use(hotMiddle(compiler));
}

app.use(express.static("public"));
const path = require("path");
app.use(express.static(path.join(__dirname, "js")));

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
