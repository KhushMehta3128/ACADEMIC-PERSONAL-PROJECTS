﻿using System.Collections.Generic;
using the_Quarterly_Sales_app.Models;

namespace the_Quarterly_Sales_app.ViewModels
{
    public class SalesViewModel
    {
        public IList<Sales> Sales { get; set; }
        public int CurrentPage { get; set; }
        public int TotalCount { get; set; }
        public int TotalPages { get; set; }
        public int PageSize { get; set; }
        public string SortOrder { get; set; }
        public int? EmployeeId { get; set; }
        public int? Year { get; set; }
        public int? Quarter { get; set; }
    }
}   