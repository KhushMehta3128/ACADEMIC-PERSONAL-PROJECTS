﻿using System;
using System.ComponentModel.DataAnnotations;

namespace the_Quarterly_Sales_app.Models
{
    public class EmployeeViewModel
    {
        public int EmployeeId { get; set; }

        [Required]
        [StringLength(50)]
        public string FirstName { get; set; }

        [Required]
        [StringLength(50)]
        public string LastName { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [Display(Name = "Date of Birth")]
        public DateTime DOB { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [Display(Name = "Date of Hire")]
        public DateTime DateOfHire { get; set; }

        public int? ManagerId { get; set; }

        [Display(Name = "Manager Name")]
        public string ManagerName { get; set; }
    }
}