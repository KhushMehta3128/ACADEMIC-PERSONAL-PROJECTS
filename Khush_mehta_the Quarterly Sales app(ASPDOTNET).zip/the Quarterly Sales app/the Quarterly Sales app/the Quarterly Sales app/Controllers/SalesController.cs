﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using the_Quarterly_Sales_app.Data;
using the_Quarterly_Sales_app.Models;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using the_Quarterly_Sales_app.ViewModels;

namespace the_Quarterly_Sales_app.Controllers
{
    public class SalesController : Controller
    {
        private readonly QuarterlySalesContext _context;
        private readonly ILogger<SalesController> _logger;

        public SalesController(QuarterlySalesContext context, ILogger<SalesController> logger)
        {
            _context = context;
            _logger = logger;
        }

        [HttpGet]
        public IActionResult Create()
        {
            // Populate the employee dropdown
            ViewBag.Employees = new SelectList(
                _context.Employees.Select(e => new { e.EmployeeId, FullName = $"{e.FirstName} {e.LastName}" }),
                "EmployeeId",
                "FullName"
            );

            return View();
        }

        [HttpGet]
        public async Task<IActionResult> Index(
            int? employeeId,
            int? year,
            int? quarter,
            string sortOrder = "year_asc")
        {
            var sales = _context.Sales.Include(s => s.Employee).AsQueryable();

            // Filter by employee
            if (employeeId.HasValue)
            {
                sales = sales.Where(s => s.EmployeeId == employeeId.Value);
            }

            // Filter by year
            if (year.HasValue)
            {
                sales = sales.Where(s => s.Year == year.Value);
            }

            // Filter by quarter
            if (quarter.HasValue)
            {
                sales = sales.Where(s => s.Quarter == quarter.Value);
            }

            // Sort the data
            switch (sortOrder)
            {
                case "year_desc":
                    sales = sales.OrderByDescending(s => s.Year);
                    break;
                case "quarter_asc":
                    sales = sales.OrderBy(s => s.Quarter);
                    break;
                case "quarter_desc":
                    sales = sales.OrderByDescending(s => s.Quarter);
                    break;
                case "amount_asc":
                    sales = sales.OrderBy(s => s.Amount);
                    break;
                case "amount_desc":
                    sales = sales.OrderByDescending(s => s.Amount);
                    break;
                case "employee_asc":
                    sales = sales.OrderBy(s => s.Employee.FirstName).ThenBy(s => s.Employee.LastName);
                    break;
                case "employee_desc":
                    sales = sales.OrderByDescending(s => s.Employee.FirstName).ThenByDescending(s => s.Employee.LastName);
                    break;
                default:
                    sales = sales.OrderBy(s => s.Year);
                    break;
            }

            // Populate the dropdowns
            ViewBag.Employees = new SelectList(
                await _context.Employees.Select(e => new { e.EmployeeId, FullName = $"{e.FirstName} {e.LastName}" }).ToListAsync(),
                "EmployeeId",
                "FullName",
                employeeId);

            ViewBag.Years = new SelectList(
                await _context.Sales.Select(s => s.Year).Distinct().ToListAsync(),
                null,
                null,
                year);

            ViewBag.Quarters = new SelectList(
                Enumerable.Range(1, 4),
                null,
                null,
                quarter);

            // Pagination
            var pageSize = 10;
            var currentPage = Request.Query.ContainsKey("page") ? int.Parse(Request.Query["page"]) : 1;
            var totalCount = await sales.CountAsync();
            var totalPages = (int)Math.Ceiling((double)totalCount / pageSize);

            var model = new SalesViewModel
            {
                Sales = await sales.Skip((currentPage - 1) * pageSize).Take(pageSize).ToListAsync(),
                CurrentPage = currentPage,
                TotalCount = totalCount,
                TotalPages = totalPages,
                PageSize = pageSize,
                SortOrder = sortOrder,
                EmployeeId = employeeId,
                Year = year,
                Quarter = quarter
            };

            return View(model);
        }

        

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Quarter,Year,Amount,EmployeeId")] Sales sales)
        {
            _logger.LogInformation($"Received sales data - Quarter: {sales.Quarter}, Year: {sales.Year}, Amount: {sales.Amount}, EmployeeId: {sales.EmployeeId}");

            // Debug: Log the current ModelState
            foreach (var modelState in ModelState)
            {
                _logger.LogInformation($"Key: {modelState.Key}");
                _logger.LogInformation($"Value: {modelState.Value?.AttemptedValue}");
                foreach (var error in modelState.Value.Errors)
                {
                    _logger.LogInformation($"Error: {error.ErrorMessage}");
                }
            }

            if (ModelState.IsValid)  // Note: Check ModelState.IsValid, not individual entries
            {
                // Verify employee exists
                var employee = await _context.Employees
                    .FirstOrDefaultAsync(e => e.EmployeeId == sales.EmployeeId);

                if (employee == null)
                {
                    ModelState.AddModelError("EmployeeId", "Selected employee does not exist.");
                    _logger.LogError($"Employee with ID {sales.EmployeeId} does not exist.");
                }
                else
                {
                    try
                    {
                        _context.Sales.Add(sales);
                        await _context.SaveChangesAsync();
                        _logger.LogInformation($"Successfully created sale record for employee {sales.EmployeeId} ({employee.FirstName} {employee.LastName})");
                        return RedirectToAction(nameof(Index));
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Error saving sales record");
                        ModelState.AddModelError(string.Empty, "An error occurred while saving the record.");
                    }
                }
            }

            // Repopulate the dropdown with the current selection
            var employees = await _context.Employees
                .Select(e => new { e.EmployeeId, FullName = $"{e.FirstName} {e.LastName}" })
                .ToListAsync();

            ViewBag.Employees = new SelectList(
                employees,
                "EmployeeId",
                "FullName",
                sales.EmployeeId  // Pass the current selection
            );

            return View(sales);
        }
    }
    }