﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Rendering;
using the_Quarterly_Sales_app.Data;
using the_Quarterly_Sales_app.Models;
using System.Linq;
using System.Threading.Tasks;

namespace the_Quarterly_Sales_app.Controllers
{
    public class EmployeesController : Controller
    {
        private readonly QuarterlySalesContext _context;

        public EmployeesController(QuarterlySalesContext context)
        {
            _context = context;
        }

        // GET: Employees
        // In EmployeesController.cs
        public async Task<IActionResult> Index()
        {
            var employees = await _context.Employees
                .Select(e => new
                {
                    Employee = e,
                    ManagerName = e.ManagerId.HasValue
                        ? _context.Employees
                            .Where(m => m.EmployeeId == e.ManagerId)
                            .Select(m => m.FirstName + " " + m.LastName)
                            .FirstOrDefault()
                        : null
                })
                .ToListAsync();

            var employeeViewModels = employees.Select(e =>
            {
                var emp = e.Employee;
                emp.Manager = e.ManagerName != null
                    ? new Employee { FirstName = e.ManagerName.Split(' ')[0], LastName = e.ManagerName.Split(' ')[1] }
                    : null;
                return emp;
            }).ToList();

            return View(employeeViewModels);
        }

        // GET: Employees/Create
        public IActionResult Create()
        {
            // Populate managers dropdown
            ViewBag.Managers = new SelectList(
                _context.Employees.Select(e => new
                {
                    e.EmployeeId,
                    FullName = $"{e.FirstName} {e.LastName}"
                }),
                "EmployeeId",
                "FullName"
            );

            return View();
        }

        // POST: Employees/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("FirstName,LastName,DOB,DateOfHire,ManagerId")] Employee employee)
        {
            // Check if a manager is selected
            if (!employee.ManagerId.HasValue)
            {
                ModelState.AddModelError("ManagerId", "Please select a manager");
            }
            else
            {
                // Validate that the selected manager exists
                var managerExists = await _context.Employees
                    .AnyAsync(e => e.EmployeeId == employee.ManagerId.Value);

                if (!managerExists)
                {
                    ModelState.AddModelError("ManagerId", "Selected manager does not exist");
                }
            }

            if (!ModelState.IsValid)
            {
                // Repopulate managers dropdown
                ViewBag.Managers = new SelectList(
                    _context.Employees.Select(e => new
                    {
                        e.EmployeeId,
                        FullName = $"{e.FirstName} {e.LastName}"
                    }),
                    "EmployeeId",
                    "FullName"
                );
                return View(employee);
            }

            // Add employee to database
            _context.Employees.Add(employee);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }
        // GET: Employees/Edit/{id}
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await _context.Employees.FindAsync(id);
            if (employee == null)
            {
                return NotFound();
            }

            // Populate managers dropdown
            ViewBag.Managers = new SelectList(
                _context.Employees.Select(e => new
                {
                    e.EmployeeId,
                    FullName = $"{e.FirstName} {e.LastName}"
                }),
                "EmployeeId",
                "FullName"
            );

            return View(employee);
        }

        // POST: Employees/Edit/{id}
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("EmployeeId,FirstName,LastName,DOB,DateOfHire,ManagerId")] Employee employee)
        {
            if (id != employee.EmployeeId)
            {
                return NotFound();
            }

            if (!ModelState.IsValid)
            {
                // Repopulate managers dropdown in case of validation failure
                ViewBag.Managers = new SelectList(
                    _context.Employees.Select(e => new
                    {
                        e.EmployeeId,
                        FullName = $"{e.FirstName} {e.LastName}"
                    }),
                    "EmployeeId",
                    "FullName"
                );
                return View(employee);
            }

            try
            {
                _context.Update(employee);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EmployeeExists(employee.EmployeeId))
                {
                    return NotFound();
                }
                throw;
            }

            return RedirectToAction(nameof(Index));
        }

        // GET: Employees/Details/{id}
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await _context.Employees
                .Include(e => e.Manager) // Include manager details
                .FirstOrDefaultAsync(m => m.EmployeeId == id);

            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }

        // GET: Employees/Delete/{id}
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await _context.Employees
                .Include(e => e.Manager)
                .FirstOrDefaultAsync(m => m.EmployeeId == id);

            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }

        // POST: Employees/Delete/{id}
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var employee = await _context.Employees.FindAsync(id);
            if (employee != null)
            {
                _context.Employees.Remove(employee);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }

        private bool EmployeeExists(int id)
        {
            return _context.Employees.Any(e => e.EmployeeId == id);
        }
    }
}
