﻿using System.ComponentModel.DataAnnotations;

namespace the_Quarterly_Sales_app.Validations
{
    public static class EmployeeValidator
    {
        public static ValidationResult ValidateDOB(DateTime dob, ValidationContext context)
        {
            if (dob >= DateTime.Now)
            {
                return new ValidationResult("Date of birth must be in the past");
            }
            return ValidationResult.Success;
        }

        public static ValidationResult ValidateDateOfHire(DateTime dateOfHire, ValidationContext context)
        {
            if (dateOfHire >= DateTime.Now)
            {
                return new ValidationResult("Date of hire must be in the past");
            }

            if (dateOfHire < new DateTime(1995, 1, 1))
            {
                return new ValidationResult("Date of hire must not be before 1/1/1995");
            }

            return ValidationResult.Success;
        }
    }
}