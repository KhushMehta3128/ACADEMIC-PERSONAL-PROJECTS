﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Reflection.Emit;
using the_Quarterly_Sales_app.Models;

namespace the_Quarterly_Sales_app.Data
{
    public class QuarterlySalesContext : DbContext
    {
        public QuarterlySalesContext(DbContextOptions<QuarterlySalesContext> options) : base(options)
        {
            try
            {
                // Try to access the database to ensure the connection is working
                var count = this.Sales.Count();
                Console.WriteLine($"Sales count: {count}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error connecting to the database: {ex.Message}");
            }
        }

        public DbSet<Employee> Employees { get; set; }
        public DbSet<Sales> Sales { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Employee>()
         .HasOne(e => e.Manager)
         .WithMany(m => m.Subordinates)
         .HasForeignKey(e => e.ManagerId)
         .IsRequired(false)
         .OnDelete(DeleteBehavior.Restrict);
        }
    }
}