# SpeakerStore

PHP Group Project

Group Number 3
Riten Patel
Mitul Mistry
Khush Mehta

note: 31b7b5f96fb9ad462826b6126a0dfb6e6bbdf970 <- this commit is combination work of Riten and Khush as first we forgot to do in git so we were handling zip file back and forth.
