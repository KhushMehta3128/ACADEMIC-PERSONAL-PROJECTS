const pageStyle = {
  borderRadius: '8px',
  boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
  padding: '20px',
  margin: '20px auto',
  backgroundColor: '#ffffff',
  maxWidth: '800px',
};

const tableStyle = {
  width: '100%',
  borderCollapse: 'collapse',
  marginTop: '20px',
};

const thStyle = {
  backgroundColor: '#f0f0f0',
  borderBottom: '1px solid #dddddd',
  padding: '10px',
  textAlign: 'left',
};

const tdStyle = {
  borderBottom: '1px solid #dddddd',
  padding: '10px',
};

const tdButtonStyle = {
  display: 'flex',
  margin: '10px',
};

const ErrorStyle = {
  color: 'red',
};

const formStyle = {
  maxWidth: '400px',
  margin: '20px auto',
};

const labelStyle = {
  display: 'block',
  marginBottom: '5px',
  fontWeight: 'bold',
};

const inputStyle = {
  width: '100%',
  padding: '8px',
  margin: '8px 0',
  boxSizing: 'border-box',
  borderRadius: '4px',
  border: '1px solid #ccc',
};

const selectStyle = {
  width: '100%',
  padding: '8px',
  margin: '8px 0',
  boxSizing: 'border-box',
  borderRadius: '4px',
  border: '1px solid #ccc',
};

const buttonStyle = {
  padding: '10px 20px',
  borderRadius: '5px',
  backgroundColor: '#007bff',
  color: '#ffffff',
  border: 'none',
  cursor: 'pointer',
  marginRight: '10px',
};

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      employees: [],
      showAddEmployee: false,
      formData: {
        firstName: '',
        lastName: '',
        age: '',
        dateOfJoining: '',
        title: '',
        department: '',
        employeeType: ''
      }
    };
  }

  // Fetch employees data from the server when the component mounts
  componentDidMount() {
    this.fetchEmployees();
  }

  // Function to fetch employees data from GraphQL server
  fetchEmployees = async () => {
    try {
      const response = await fetch('/graphql', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          query: `
            query {
              listEmployees {
                emp_id
                firstName
                lastName
                age
                dateOfJoining
                title
                department
                employeeType
                Currentstatus
              }
            }
          `
        })
      });
      const result = await response.json();
      // Update state with fetched employees data
      this.setState({
        employees: result.data.listEmployees
      });
    } catch (error) {
      console.error("Error fetching employees:", error);
    }
  };

  // Handle change in form input fields
  handleChange = e => {
    const { name, value } = e.target;
    this.setState(prevState => ({
      formData: {
        ...prevState.formData,
        [name]: value
      }
    }));
  };

  // Toggle the visibility of the add employee form
  handleAddEmployee = () => {
    this.setState(prevState => ({
      showAddEmployee: !prevState.showAddEmployee
    }));
  };

  // Handle form submission to add a new employee
  handleSubmit = async e => {
    e.preventDefault();
    try {
      const { formData } = this.state;
      const response = await fetch('/graphql', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          query: `
            mutation ($employee: EmployeeInput!) {
              addEmployee(employee: $employee) {
                emp_id
                firstName
                lastName
                age
                dateOfJoining
                title
                department
                employeeType
                Currentstatus
              }
            }
          `,
          variables: {
            employee: formData
          }
        })
      });
      const result = await response.json();
      // Update state with the newly added employee
      this.setState(prevState => ({
        employees: [...prevState.employees, result.data.addEmployee],
        showAddEmployee: false,
        formData: {
          firstName: '',
          lastName: '',
          age: '',
          dateOfJoining: '',
          title: '',
          department: '',
          employeeType: ''
        }
      }));
    } catch (error) {
      console.error("Error adding employee:", error);
    }
  };

  render() {
    const { employees, showAddEmployee, formData } = this.state;
    return (
      <div style={pageStyle}>
        <h1>Employees</h1>
        {/* Display message when no employees are added */}
        {employees.length === 0 && (
        <p style={ErrorStyle}>No employees added yet.</p>
      )}
      {/* Render table if there are employees */}
        <table style={tableStyle}>
          <thead>
            <tr>
              <th style={thStyle}>#</th>
              <th style={thStyle}>Name</th>
              <th style={thStyle}>Age</th>
              <th style={thStyle}>Date of Joining</th>
              <th style={thStyle}>Title</th>
              <th style={thStyle}>Department</th>
              <th style={thStyle}>Employee Type</th>
              <th style={thStyle}>Currentstatus</th>
              <th style={thStyle}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {/* Map through employees and render each row */}
            {employees.map((employee, index) => (
              <tr key={employee.emp_id}>
                <td style={tdStyle}>{index + 1}</td>
                <td style={tdStyle}>{`${employee.firstName} ${employee.lastName}`}</td>
                <td style={tdStyle}>{employee.age}</td>
                <td style={tdStyle}>{new Date(employee.dateOfJoining).toLocaleDateString()}</td>
                <td style={tdStyle}>{employee.title}</td>
                <td style={tdStyle}>{employee.department}</td>
                <td style={tdStyle}>{employee.employeeType}</td>
                <td style={tdStyle}>{employee.Currentstatus ? 'Working' : 'Retired'}</td>
                <td style={tdButtonStyle}>
                  <button style={buttonStyle}>Edit</button>
                  <button style={buttonStyle}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {/* Button to toggle add employee form */}
        <button type="button" onClick={this.handleAddEmployee} style={buttonStyle}>
          {showAddEmployee ? 'Close' : 'Add Employee'}
        </button>
        {/* Render add employee form if showAddEmployee is true */}
        {showAddEmployee && (
          <div style={formStyle}>
            <h2>Create New Employee</h2>
            <form onSubmit={this.handleSubmit}>
              {/* Input fields for employee details */}
              <div style={formStyle}>
                <label style={labelStyle}>First Name</label>
                <input
                  type="text"
                  className="form-control"
                  name="firstName"
                  value={formData.firstName}
                  onChange={this.handleChange}
                  required
                  style={inputStyle}
                />
              </div>
              <div style={formStyle}>
                <label style={labelStyle}>Last Name</label>
                <input
                  type="text"
                  className="form-control"
                  name="lastName"
                  value={formData.lastName}
                  onChange={this.handleChange}
                  required
                  style={inputStyle}
                />
              </div>
              <div style={formStyle}>
                <label style={labelStyle}>Age</label>
                <input
                  type="number"
                  className="form-control"
                  name="age"
                  value={formData.age}
                  onChange={this.handleChange}
                  required
                  min="20"
                  max="70"
                  style={inputStyle}
                />
              </div>
              <div style={formStyle}>
                <label style={labelStyle}>Date of Joining</label>
                <input
                  type="date"
                  className="form-control"
                  name="dateOfJoining"
                  value={formData.dateOfJoining}
                  onChange={this.handleChange}
                  required
                  style={inputStyle}
                />
              </div>
              <div style={formStyle}>
                <label style={labelStyle}>Title</label>
                <select
                  className="form-control"
                  name="title"
                  value={formData.title}
                  onChange={this.handleChange}
                  required
                  style={selectStyle}
                >
                  <option value="">Select Title</option>
                  <option value="Employee">Employee</option>
                  <option value="Manager">Manager</option>
                  <option value="Director">Director</option>
                  <option value="VP">VP</option>
                </select>
              </div>
              <div style={formStyle}>
                <label style={labelStyle}>Department</label>
                <select
                  className="form-control"
                  name="department"
                  value={formData.department}
                  onChange={this.handleChange}
                  required
                  style={selectStyle}
                >
                  <option value="">Select Department</option>
                  <option value="IT">IT</option>
                  <option value="Marketing">Marketing</option>
                  <option value="HR">HR</option>
                  <option value="Engineering">Engineering</option>
                </select>
              </div>
              <div style={formStyle}>
                <label style={labelStyle}>Employee Type</label>
                <select
                  className="form-control"
                  name="employeeType"
                  value={formData.employeeType}
                  onChange={this.handleChange}
                  required
                  style={selectStyle}
                >
                  <option value="">Select Employee Type</option>
                  <option value="FullTime">Full Time</option>
                  <option value="PartTime">Part Time</option>
                  <option value="Contract">Contract</option>
                  <option value="Seasonal">Seasonal</option>
                </select>
              </div>
              <button type="submit" style={buttonStyle}>
                Submit
              </button>
            </form>
          </div>
        )}
      </div>
    );
  }
}

ReactDOM.render(<App />, document.getElementById('contents'));
