const pageStyle = {
  borderRadius: '8px',
  boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
  padding: '20px',
  margin: '20px auto',
  backgroundColor: '#ffffff',
  maxWidth: '800px'
};
const tableStyle = {
  width: '100%',
  borderCollapse: 'collapse',
  marginTop: '20px'
};
const thStyle = {
  backgroundColor: '#f0f0f0',
  borderBottom: '1px solid #dddddd',
  padding: '10px',
  textAlign: 'left'
};
const tdStyle = {
  borderBottom: '1px solid #dddddd',
  padding: '10px'
};
const tdButtonStyle = {
  display: 'flex',
  margin: '10px'
};
const ErrorStyle = {
  color: 'red'
};
const formStyle = {
  maxWidth: '400px',
  margin: '20px auto'
};
const labelStyle = {
  display: 'block',
  marginBottom: '5px',
  fontWeight: 'bold'
};
const inputStyle = {
  width: '100%',
  padding: '8px',
  margin: '8px 0',
  boxSizing: 'border-box',
  borderRadius: '4px',
  border: '1px solid #ccc'
};
const selectStyle = {
  width: '100%',
  padding: '8px',
  margin: '8px 0',
  boxSizing: 'border-box',
  borderRadius: '4px',
  border: '1px solid #ccc'
};
const buttonStyle = {
  padding: '10px 20px',
  borderRadius: '5px',
  backgroundColor: '#007bff',
  color: '#ffffff',
  border: 'none',
  cursor: 'pointer',
  marginRight: '10px'
};
class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      employees: [],
      showAddEmployee: false,
      formData: {
        firstName: '',
        lastName: '',
        age: '',
        dateOfJoining: '',
        title: '',
        department: '',
        employeeType: ''
      }
    };
  }

  // Fetch employees data from the server when the component mounts
  componentDidMount() {
    this.fetchEmployees();
  }

  // Function to fetch employees data from GraphQL server
  fetchEmployees = async () => {
    try {
      const response = await fetch('/graphql', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          query: `
            query {
              listEmployees {
                emp_id
                firstName
                lastName
                age
                dateOfJoining
                title
                department
                employeeType
                Currentstatus
              }
            }
          `
        })
      });
      const result = await response.json();
      // Update state with fetched employees data
      this.setState({
        employees: result.data.listEmployees
      });
    } catch (error) {
      console.error("Error fetching employees:", error);
    }
  };

  // Handle change in form input fields
  handleChange = e => {
    const {
      name,
      value
    } = e.target;
    this.setState(prevState => ({
      formData: {
        ...prevState.formData,
        [name]: value
      }
    }));
  };

  // Toggle the visibility of the add employee form
  handleAddEmployee = () => {
    this.setState(prevState => ({
      showAddEmployee: !prevState.showAddEmployee
    }));
  };

  // Handle form submission to add a new employee
  handleSubmit = async e => {
    e.preventDefault();
    try {
      const {
        formData
      } = this.state;
      const response = await fetch('/graphql', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          query: `
            mutation ($employee: EmployeeInput!) {
              addEmployee(employee: $employee) {
                emp_id
                firstName
                lastName
                age
                dateOfJoining
                title
                department
                employeeType
                Currentstatus
              }
            }
          `,
          variables: {
            employee: formData
          }
        })
      });
      const result = await response.json();
      // Update state with the newly added employee
      this.setState(prevState => ({
        employees: [...prevState.employees, result.data.addEmployee],
        showAddEmployee: false,
        formData: {
          firstName: '',
          lastName: '',
          age: '',
          dateOfJoining: '',
          title: '',
          department: '',
          employeeType: ''
        }
      }));
    } catch (error) {
      console.error("Error adding employee:", error);
    }
  };
  render() {
    const {
      employees,
      showAddEmployee,
      formData
    } = this.state;
    return /*#__PURE__*/React.createElement("div", {
      style: pageStyle
    }, /*#__PURE__*/React.createElement("h1", null, "Employees"), employees.length === 0 && /*#__PURE__*/React.createElement("p", {
      style: ErrorStyle
    }, "No employees added yet."), /*#__PURE__*/React.createElement("table", {
      style: tableStyle
    }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", {
      style: thStyle
    }, "#"), /*#__PURE__*/React.createElement("th", {
      style: thStyle
    }, "Name"), /*#__PURE__*/React.createElement("th", {
      style: thStyle
    }, "Age"), /*#__PURE__*/React.createElement("th", {
      style: thStyle
    }, "Date of Joining"), /*#__PURE__*/React.createElement("th", {
      style: thStyle
    }, "Title"), /*#__PURE__*/React.createElement("th", {
      style: thStyle
    }, "Department"), /*#__PURE__*/React.createElement("th", {
      style: thStyle
    }, "Employee Type"), /*#__PURE__*/React.createElement("th", {
      style: thStyle
    }, "Currentstatus"), /*#__PURE__*/React.createElement("th", {
      style: thStyle
    }, "Actions"))), /*#__PURE__*/React.createElement("tbody", null, employees.map((employee, index) => /*#__PURE__*/React.createElement("tr", {
      key: employee.emp_id
    }, /*#__PURE__*/React.createElement("td", {
      style: tdStyle
    }, index + 1), /*#__PURE__*/React.createElement("td", {
      style: tdStyle
    }, `${employee.firstName} ${employee.lastName}`), /*#__PURE__*/React.createElement("td", {
      style: tdStyle
    }, employee.age), /*#__PURE__*/React.createElement("td", {
      style: tdStyle
    }, new Date(employee.dateOfJoining).toLocaleDateString()), /*#__PURE__*/React.createElement("td", {
      style: tdStyle
    }, employee.title), /*#__PURE__*/React.createElement("td", {
      style: tdStyle
    }, employee.department), /*#__PURE__*/React.createElement("td", {
      style: tdStyle
    }, employee.employeeType), /*#__PURE__*/React.createElement("td", {
      style: tdStyle
    }, employee.Currentstatus ? 'Working' : 'Retired'), /*#__PURE__*/React.createElement("td", {
      style: tdButtonStyle
    }, /*#__PURE__*/React.createElement("button", {
      style: buttonStyle
    }, "Edit"), /*#__PURE__*/React.createElement("button", {
      style: buttonStyle
    }, "Delete")))))), /*#__PURE__*/React.createElement("button", {
      type: "button",
      onClick: this.handleAddEmployee,
      style: buttonStyle
    }, showAddEmployee ? 'Close' : 'Add Employee'), showAddEmployee && /*#__PURE__*/React.createElement("div", {
      style: formStyle
    }, /*#__PURE__*/React.createElement("h2", null, "Create New Employee"), /*#__PURE__*/React.createElement("form", {
      onSubmit: this.handleSubmit
    }, /*#__PURE__*/React.createElement("div", {
      style: formStyle
    }, /*#__PURE__*/React.createElement("label", {
      style: labelStyle
    }, "First Name"), /*#__PURE__*/React.createElement("input", {
      type: "text",
      className: "form-control",
      name: "firstName",
      value: formData.firstName,
      onChange: this.handleChange,
      required: true,
      style: inputStyle
    })), /*#__PURE__*/React.createElement("div", {
      style: formStyle
    }, /*#__PURE__*/React.createElement("label", {
      style: labelStyle
    }, "Last Name"), /*#__PURE__*/React.createElement("input", {
      type: "text",
      className: "form-control",
      name: "lastName",
      value: formData.lastName,
      onChange: this.handleChange,
      required: true,
      style: inputStyle
    })), /*#__PURE__*/React.createElement("div", {
      style: formStyle
    }, /*#__PURE__*/React.createElement("label", {
      style: labelStyle
    }, "Age"), /*#__PURE__*/React.createElement("input", {
      type: "number",
      className: "form-control",
      name: "age",
      value: formData.age,
      onChange: this.handleChange,
      required: true,
      min: "20",
      max: "70",
      style: inputStyle
    })), /*#__PURE__*/React.createElement("div", {
      style: formStyle
    }, /*#__PURE__*/React.createElement("label", {
      style: labelStyle
    }, "Date of Joining"), /*#__PURE__*/React.createElement("input", {
      type: "date",
      className: "form-control",
      name: "dateOfJoining",
      value: formData.dateOfJoining,
      onChange: this.handleChange,
      required: true,
      style: inputStyle
    })), /*#__PURE__*/React.createElement("div", {
      style: formStyle
    }, /*#__PURE__*/React.createElement("label", {
      style: labelStyle
    }, "Title"), /*#__PURE__*/React.createElement("select", {
      className: "form-control",
      name: "title",
      value: formData.title,
      onChange: this.handleChange,
      required: true,
      style: selectStyle
    }, /*#__PURE__*/React.createElement("option", {
      value: ""
    }, "Select Title"), /*#__PURE__*/React.createElement("option", {
      value: "Employee"
    }, "Employee"), /*#__PURE__*/React.createElement("option", {
      value: "Manager"
    }, "Manager"), /*#__PURE__*/React.createElement("option", {
      value: "Director"
    }, "Director"), /*#__PURE__*/React.createElement("option", {
      value: "VP"
    }, "VP"))), /*#__PURE__*/React.createElement("div", {
      style: formStyle
    }, /*#__PURE__*/React.createElement("label", {
      style: labelStyle
    }, "Department"), /*#__PURE__*/React.createElement("select", {
      className: "form-control",
      name: "department",
      value: formData.department,
      onChange: this.handleChange,
      required: true,
      style: selectStyle
    }, /*#__PURE__*/React.createElement("option", {
      value: ""
    }, "Select Department"), /*#__PURE__*/React.createElement("option", {
      value: "IT"
    }, "IT"), /*#__PURE__*/React.createElement("option", {
      value: "Marketing"
    }, "Marketing"), /*#__PURE__*/React.createElement("option", {
      value: "HR"
    }, "HR"), /*#__PURE__*/React.createElement("option", {
      value: "Engineering"
    }, "Engineering"))), /*#__PURE__*/React.createElement("div", {
      style: formStyle
    }, /*#__PURE__*/React.createElement("label", {
      style: labelStyle
    }, "Employee Type"), /*#__PURE__*/React.createElement("select", {
      className: "form-control",
      name: "employeeType",
      value: formData.employeeType,
      onChange: this.handleChange,
      required: true,
      style: selectStyle
    }, /*#__PURE__*/React.createElement("option", {
      value: ""
    }, "Select Employee Type"), /*#__PURE__*/React.createElement("option", {
      value: "FullTime"
    }, "Full Time"), /*#__PURE__*/React.createElement("option", {
      value: "PartTime"
    }, "Part Time"), /*#__PURE__*/React.createElement("option", {
      value: "Contract"
    }, "Contract"), /*#__PURE__*/React.createElement("option", {
      value: "Seasonal"
    }, "Seasonal"))), /*#__PURE__*/React.createElement("button", {
      type: "submit",
      style: buttonStyle
    }, "Submit"))));
  }
}
ReactDOM.render( /*#__PURE__*/React.createElement(App, null), document.getElementById('contents'));