const { MongoClient } = require("mongodb");
const { GraphQLScalarType, Kind } = require("graphql");

const DB_URL = "mongodb+srv://Khush:Khush123@adfullstack.nkbdwsh.mongodb.net/";

let db = null;
let employeeCollection = null;

const connectToDB = async () => {
  const client = new MongoClient(DB_URL, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });

  await client.connect();
  console.log("Database connected successfully");
  db = client.db("AdFullstack");

  employeeCollection = db.collection("employees");

  // Ensure indexes are created
  await employeeCollection.createIndex({ emp_id: 1 }, { unique: true });
};

const DateScalar = new GraphQLScalarType({
  name: "Date",
  description: "Custom Date scalar type",
  serialize(value) {
    return value instanceof Date ? value.toISOString() : null;
  },
  parseValue(value) {
    return value ? new Date(value) : null;
  },
  parseLiteral(ast) {
    return ast.kind === Kind.STRING ? new Date(ast.value) : null;
  },
});

const getDBEmployees = async () => {
  return await employeeCollection.find().toArray();
};

const addDBEmployee = async (employee) => {
  return await employeeCollection.insertOne(employee);
};



module.exports = {
  connectToDB,
  getDBEmployees,
  addDBEmployee,
  DateScalar,
};
