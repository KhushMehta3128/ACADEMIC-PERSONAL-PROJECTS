const express = require("express");
const { ApolloServer, gql } = require("apollo-server-express");
const { GraphQLScalarType, Kind } = require("graphql");
const { uid } = require("uid");
const {
  getDBEmployees,
  addDBEmployee,
  connectToDB,
} = require("./dbconnect");

let aboutMessage = "Welcome to the Employee Management System";

// GraphQL schema 
const typeDefs = gql`
  scalar Date

  type Employee {
    emp_id: String!
    firstName: String!
    lastName: String!
    age: String!
    dateOfJoining: Date!
    title: String!
    department: String!
    employeeType: String!
    Currentstatus: Boolean!
    created: Date!
  }

  type Query {
    about: String!
    listEmployees: [Employee!]!
  }

  type Mutation {
    setAbout(message: String!): String
    addEmployee(employee: EmployeeInput!): Employee!
    deleteEmployee(emp_id: String!): String
    editEmployee(emp_id: String!, details: EmployeeEditInput!): Employee!
  }

  input EmployeeInput {
    firstName: String!
    lastName: String!
    age: String!
    dateOfJoining: Date!
    title: String!
    department: String!
    employeeType: String!
  }

  input EmployeeEditInput {
    title: String
    department: String
    employeeType: String
    Currentstatus: Boolean
  }
`;

// Custom Date scalar 
const DateScalar = new GraphQLScalarType({
  name: "Date",
  description: "Custom Date scalar type",
  serialize(value) {
    return value instanceof Date ? value.toISOString() : null;
  },
  parseValue(value) {
    return value ? new Date(value) : null;
  },
  parseLiteral(ast) {
    return ast.kind === Kind.STRING ? new Date(ast.value) : null;
  },
});

// Function to validate employee input against predefined values
const validateEmployeeInput = (employee) => {
  const titles = ["Employee", "Manager", "Director", "VP"];
  const departments = ["IT", "Marketing", "HR", "Engineering"];
  const employeeTypes = ["FullTime", "PartTime", "Contract", "Seasonal"];
  const { age, title, department, employeeType } = employee;

  if (age < 20 || age > 70) throw new Error("Age must be between 20 and 70.");
  if (!titles.includes(title)) throw new Error("Invalid title.");
  if (!departments.includes(department)) throw new Error("Invalid department.");
  if (!employeeTypes.includes(employeeType)) throw new Error("Invalid employee type.");
};

// Resolvers define the implementation of the GraphQL schema
const resolvers = {
  Date: DateScalar,
  Query: {
    about: () => aboutMessage,
    listEmployees: async () => await getDBEmployees(),
  },
  Mutation: {
    setAbout: (_, { message }) => {
      aboutMessage = message;
      return aboutMessage;
    },
    addEmployee: async (_, { employee }) => {
      // Resolver to add a new employee
      console.log({employee});

      const newEmployee = {
        ...employee,
        emp_id: uid(8),
        dateOfJoining: new Date(employee.dateOfJoining),
        created: new Date(),
        Currentstatus: true,
        age:Number(employee.age)
      };
      const result = await addDBEmployee(newEmployee);

      console.log({result});
try {
  if (result.acknowledged) {
    return newEmployee; // Return newly added employee on success
  } 

} catch (error) {
  throw new Error("Failed to add employee. ",error);
  
}
     
    },
  },
};

const app = express();
const server = new ApolloServer({ typeDefs, resolvers }); // Create Apollo Server instance

const startServer = async () => {
  await server.start();
  await connectToDB();
  server.applyMiddleware({ app, path: "/graphql" });  // Apply Apollo Server middleware to Express app
};

startServer();

app.use(express.static("public"));
app.listen(8000, () => {
  console.log("Server is running on http://localhost:8000");
});
