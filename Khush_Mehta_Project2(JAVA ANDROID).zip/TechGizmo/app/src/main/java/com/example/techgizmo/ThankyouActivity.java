package com.example.techgizmo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class ThankyouActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.thankyou);


        Button redirectButton = findViewById(R.id.redirectbtn);


        redirectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent productIntent = new Intent(ThankyouActivity.this, ProductActivity.class);
                startActivity(productIntent);

                finish();
            }
        });
    }
}