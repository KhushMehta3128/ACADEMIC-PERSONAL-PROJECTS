package com.example.techgizmo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

public class ProductDetailsActivity extends AppCompatActivity {
    private ImageView productImg;
    private TextView productName;
    private TextView productPrice;
    private TextView productDescription;
    private Button addToCartButton;
    private Button increaseQuantityButton;
    private Button decreaseQuantityButton;
    private TextView quantityTextView;
    private Product selectedProduct;

    private int quantity = 1;
    private double initialPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.productdetails);

        // Initialize views
        productImg = findViewById(R.id.productImg);
        productName = findViewById(R.id.productName);
        productPrice = findViewById(R.id.productPrice);
        productDescription = findViewById(R.id.productDescription);
        addToCartButton = findViewById(R.id.addtocart);
        increaseQuantityButton = findViewById(R.id.increaseQuantityButton);
        decreaseQuantityButton = findViewById(R.id.decreaseQuantityButton);
        quantityTextView = findViewById(R.id.quantityTextView);


        // Retrieve the selected product from intent extras
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("selectedProduct")) {
             selectedProduct = (Product) intent.getSerializableExtra("selectedProduct");
            // Populate views with product data
            Glide.with(this).load(selectedProduct.getImageResource()).into(productImg);
            productName.setText(selectedProduct.getTitle());
            initialPrice = selectedProduct.getPrice();
            updateProductPrice(initialPrice);
            productPrice.setText("$" + String.valueOf(initialPrice));
            productDescription.setText(selectedProduct.getDescription());
        }

        ImageView mylogoImageView = findViewById(R.id.mylogo);
        mylogoImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirect to CartActivity
                Intent cartIntent = new Intent(ProductDetailsActivity.this, ProductActivity.class);

                startActivity(cartIntent);
            }
        });
        ImageView myCartImageView = findViewById(R.id.mycart);
        myCartImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirect to CartActivity
                Intent cartIntent = new Intent(ProductDetailsActivity.this, CartActivity.class);
                cartIntent.putExtra("productImg", selectedProduct.getImageResource());
                cartIntent.putExtra("productName", selectedProduct.getTitle());
                cartIntent.putExtra("productPrice", initialPrice); // Pass the initial price
                cartIntent.putExtra("quantity", quantity); // Pass the updated quantity
                startActivity(cartIntent);
            }
        });

        // Add click listener to add to cart button
        addToCartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(ProductDetailsActivity.this, "Product added to cart", Toast.LENGTH_SHORT).show();

                // Pass the product details to CartActivity
                Intent cartIntent = new Intent(ProductDetailsActivity.this, CartActivity.class);
                cartIntent.putExtra("productImg", selectedProduct.getImageResource());
                cartIntent.putExtra("productName", selectedProduct.getTitle());
                cartIntent.putExtra("productPrice", initialPrice); // Pass the initial price
                cartIntent.putExtra("quantity", quantity); // Pass the updated quantity
            }
        });
        increaseQuantityButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                quantity++;
                updateQuantityAndPrice();
            }
        });

        decreaseQuantityButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (quantity > 1) {
                    quantity--;
                    updateQuantityAndPrice();
                } else {
                    Toast.makeText(ProductDetailsActivity.this, "Quantity cannot be less than 1", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Update quantity and total price
    private void updateQuantityAndPrice() {
        quantityTextView.setText(String.valueOf(quantity));
        double totalPrice = initialPrice * quantity;
        updateProductPrice(totalPrice);
    }

    private void updateProductPrice(double price) {
        productPrice.setText("$" + String.format("%.2f", price));
    }
}