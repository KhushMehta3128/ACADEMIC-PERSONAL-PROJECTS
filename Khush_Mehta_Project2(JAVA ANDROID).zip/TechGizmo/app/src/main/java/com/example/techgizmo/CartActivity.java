package com.example.techgizmo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class CartActivity extends AppCompatActivity implements CartAdapter.RemoveProductListener {
    private RecyclerView cartRecyclerView;
    private CartAdapter cartAdapter;
    private List<Product> cartItemList;
    private Button checkoutButton;
    private Product selectedProduct;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cartpage);

        // Initialize RecyclerView
        cartRecyclerView = findViewById(R.id.cartRecycler);
        cartItemList = new ArrayList<>();
        cartAdapter = new CartAdapter(this, cartItemList, this );

        // Set RecyclerView layout manager and adapter
        cartRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        cartRecyclerView.setAdapter(cartAdapter);

        // Retrieve product details from intent extras
        Intent intent = getIntent();
        String productDescription = intent.getStringExtra("productDescription");

        if (intent != null) {
            String productImg = intent.getStringExtra("productImg");
            String productName = intent.getStringExtra("productName");
            double productPrice = intent.getDoubleExtra("productPrice", 0.0);
            int quantity = intent.getIntExtra("quantity", 1);

            // Add the product to the cart
            Product product = new Product(productName, productPrice, productImg, productDescription, quantity);
            product.setQuantity(quantity);
            cartItemList.add(product);

            // Notify adapter that data has changed
            cartAdapter.notifyDataSetChanged();
        }
        ImageView mylogoImageView = findViewById(R.id.mylogo);
        mylogoImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirect to CartActivity
                Intent cartIntent = new Intent(CartActivity.this, ProductActivity.class);

                startActivity(cartIntent);
            }
        });
        checkoutButton = findViewById(R.id.Chkoutbtn);

        checkoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirect to CartActivity
                Intent cartIntent = new Intent(CartActivity.this, CheckoutActivity.class);

                startActivity(cartIntent);
            }
        });
    }

    @Override
    public void onRemoveProduct(int position) {
        cartItemList.remove(position);
        cartAdapter.notifyDataSetChanged();
        // Add any additional logic here, such as updating total price, saving changes, etc.
    }
}