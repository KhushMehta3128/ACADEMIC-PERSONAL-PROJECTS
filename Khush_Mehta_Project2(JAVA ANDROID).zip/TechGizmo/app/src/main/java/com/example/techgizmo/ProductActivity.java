    package com.example.techgizmo;

    import android.content.Intent;
    import android.os.Bundle;
    import android.view.View;
    import android.widget.ImageView;
    import android.widget.Toast;

    import androidx.annotation.NonNull;
    import androidx.appcompat.app.AppCompatActivity;
    import androidx.recyclerview.widget.GridLayoutManager;
    import androidx.recyclerview.widget.RecyclerView;
    import com.google.firebase.database.DatabaseReference;
    import com.google.firebase.database.FirebaseDatabase;
    import com.google.firebase.database.DataSnapshot;
    import com.google.firebase.database.DatabaseError;
    import com.google.firebase.database.ValueEventListener;

    import java.util.ArrayList;
    import java.util.List;

    public class ProductActivity extends AppCompatActivity {
        private RecyclerView recyclerView;
        private ProductAdapter adapter;
        private List<Product> productList;
        private DatabaseReference databaseReference;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.product);

            // Initialize RecyclerView
            recyclerView = findViewById(R.id.productRecycler);
            productList = new ArrayList<>();
            adapter = new ProductAdapter(this, productList);
            recyclerView.setAdapter(adapter);

            // Use GridLayoutManager with 2 columns
            recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

            // Initialize Firebase
            databaseReference = FirebaseDatabase.getInstance().getReference().child("products");

            // Fetch data from Firebase
            databaseReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    // Clear the list before adding new data
                    productList.clear();

                    // Iterate through the products node
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        // Get product details
                        String productName = snapshot.child("productName").getValue(String.class);
                        double productPrice = snapshot.child("productPrice").getValue(Double.class);
                        String productImg = snapshot.child("productImg").getValue(String.class);
                        String productDescription = snapshot.child("productDescription").getValue(String.class);
//                        Intent intent = null;
//                        int quantity = intent.getIntExtra("quantity", 1);


                        // Create Product object and add it to the list
                        int quantity = 1;
                        Product product = new Product(productName, productPrice, productImg, productDescription, quantity);
                        productList.add(product);

                    }

                    // Notify adapter that data has changed
                    adapter.notifyDataSetChanged();

                    ImageView mylogoImageView = findViewById(R.id.mylogo);
                    mylogoImageView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            // Redirect to CartActivity
                            Intent cartIntent = new Intent(ProductActivity.this, ProductActivity.class);

                            startActivity(cartIntent);
                        }
                    });
                }
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(ProductActivity.this, "Error fetching data: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                }

            });
        }
    }