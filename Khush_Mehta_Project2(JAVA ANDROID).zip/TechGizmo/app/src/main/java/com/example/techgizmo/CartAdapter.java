package com.example.techgizmo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.ViewHolder> {
    private Context context;
    private List<Product> cartItemList;
    private RemoveProductListener removeProductListener;
    public interface RemoveProductListener {
        void onRemoveProduct(int position);
    }

    public CartAdapter(Context context, List<Product> cartItemList, RemoveProductListener removeProductListener) {
        this.context = context;
        this.cartItemList = cartItemList;
        this.removeProductListener = removeProductListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.cartproductcv, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Product product = cartItemList.get(position);
        double totalPrice = product.getPrice() * product.getQuantity();
        // Bind product data to views
        Glide.with(context).load(product.getImageResource()).into(holder.productImg);
        holder.productName.setText(product.getTitle());
        holder.productPrice.setText("$" + String.format("%.2f", totalPrice));
        holder.quantityTextView.setText(String.valueOf(product.getQuantity()));
        holder.removeProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (removeProductListener != null) {
                    removeProductListener.onRemoveProduct(position);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return cartItemList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView productImg;
        TextView productName;
        TextView productPrice;
        TextView quantityTextView;
        Button removeProduct;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            productImg = itemView.findViewById(R.id.productImg);
            productName = itemView.findViewById(R.id.productName);
            productPrice = itemView.findViewById(R.id.productPrice);
            quantityTextView = itemView.findViewById(R.id.quantityTextView);
            removeProduct = itemView.findViewById(R.id.removeProduct);
        }
    }
}
