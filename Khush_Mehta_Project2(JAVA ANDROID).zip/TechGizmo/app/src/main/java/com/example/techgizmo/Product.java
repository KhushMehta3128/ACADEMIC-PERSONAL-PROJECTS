package com.example.techgizmo;

import java.io.Serializable;

public class Product implements Serializable {
    private String productImg;
    private String productName;
    private double productPrice;
    private String productDescription;
    private int quantity;

    public Product(String productName, double productPrice, String productImg, String productDescription, int quantity) {
        this.productImg = productImg;
        this.productName = productName;
        this.productPrice = productPrice;
        this.productDescription = productDescription;
        this.quantity = 1;
    }

    public String getImageResource() {
        return productImg;
    }

    public String getTitle() {
        return productName;
    }

    public double getPrice() {
        return productPrice;
    }

    public String getDescription() {
        return productDescription;
    }

    public int getQuantity() {
        return quantity;
    }
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}