package com.example.techgizmo;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CheckoutActivity extends AppCompatActivity {

    private TextInputEditText addressEditText;
    private TextInputEditText cityEditText;
    private TextInputEditText postalCodeEditText;
    private TextInputEditText cardNoEditText;
    private TextInputEditText cvvEditText;
    private TextInputEditText expiryEditText;
    private TextView productPriceTextView;
    private Button checkoutButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.checkoutpage);

        addressEditText = findViewById(R.id.address);
        cityEditText = findViewById(R.id.City);
        postalCodeEditText = findViewById(R.id.Postalcode);
        cardNoEditText = findViewById(R.id.Cardno);
        cvvEditText = findViewById(R.id.CVV);
        expiryEditText = findViewById(R.id.expiry);
        checkoutButton = findViewById(R.id.tothankyou);


        checkoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateInputs()) {
                    // Proceed with checkout
                    Toast.makeText(CheckoutActivity.this, "Checkout Successful", Toast.LENGTH_SHORT).show();
                    Intent thankYouIntent = new Intent(CheckoutActivity.this, ThankyouActivity.class);
                    startActivity(thankYouIntent);
                    // Add code to proceed with checkout
                }
            }
        });
    }

    private boolean validateInputs() {
        String address = addressEditText.getText().toString().trim();
        String city = cityEditText.getText().toString().trim();
        String postalCode = postalCodeEditText.getText().toString().trim();
        String cardNo = cardNoEditText.getText().toString().trim();
        String cvv = cvvEditText.getText().toString().trim();
        String expiry = expiryEditText.getText().toString().trim();

        // Validate address (can be any non-empty string)
        if (TextUtils.isEmpty(address)) {
            addressEditText.setError("Enter address");
            return false;
        }

        // Validate city (alphabets only)
        if (!isValidCity(city)) {
            cityEditText.setError("Enter valid city");
            return false;
        }

        // Validate postal code (6 letters)
        if (!isValidPostalCode(postalCode)) {
            postalCodeEditText.setError("Enter valid postal code");
            return false;
        }

        // Validate card number (numbers only)
        if (!isValidCardNumber(cardNo)) {
            cardNoEditText.setError("Enter valid card number");
            return false;
        }

        // Validate CVV (3 numbers only)
        if (!isValidCVV(cvv)) {
            cvvEditText.setError("Enter valid CVV");
            return false;
        }

        // Validate expiry date (format MM/YY)
        if (!isValidExpiry(expiry)) {
            expiryEditText.setError("Enter valid expiry date (MM/YY)");
            return false;
        }

        return true;
    }

    private boolean isValidCity(String city) {
        return Pattern.matches("[a-zA-Z]+", city);
    }

    private boolean isValidPostalCode(String postalCode) {
        return postalCode.length() == 6;
    }

    private boolean isValidCardNumber(String cardNo) {
        return TextUtils.isDigitsOnly(cardNo);
    }

    private boolean isValidCVV(String cvv) {
        return Pattern.matches("\\d{3}", cvv);
    }

    private boolean isValidExpiry(String expiry) {
        return Pattern.matches("\\d{2}/\\d{2}", expiry);
    }
}
