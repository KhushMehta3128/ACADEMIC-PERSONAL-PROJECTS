import React from 'react';


const HomePage = () => {
  return (
    // Meet Amin 
    <div>
      <main className="main-container">
        <section className="mainContent">
          <div className="content-div Cards">
            <h1>Best Games</h1>
            <h4 className="typewriter">Explore the world of "Gaming" with us</h4>
          </div>
          <div className="content-div Cards">
            <img className="Sip" src="Images/Games/Logo.png" alt="Error" />
          </div>
        </section>
        <hr />
        <section className="topSellers ourTeam">
          <h2>Proud Moments</h2>
          <div className="cardsContainer backGround">
            <div className="video-container">
              <img
                src="Images/Games/EldenRing.jpg"
                alt="Elden Ring"
                className="image"
              />
              <div className="video-overlay">
              </div>
              <h1 className="gameName">Elden Ring</h1>
            </div>
            <div className="video-container">
              <img
                src="Images/Games/GhostOfTsushima.jpg"
                alt="Ghost of Tsushima"
                className="image"
              />
              <div className="video-overlay">
              </div>
              <h1 className="gameName">Ghost of Tsushima</h1>
            </div>
            <div className="video-container">
              <img
                src="Images/Games/RedDeadRedemption2.jpg"
                alt="RedDeadRedemption2"
                className="image"
              />
              <div className="video-overlay">
              </div>
              <h1 className="gameName">Red Dead Redemption 2</h1>
            </div>

            <div className="video-container">
              <img
                src="Images/Games/Lastofus.jpg"
                alt="The Last of Us Part II"
                className="image"
              />
              <div className="video-overlay">
              </div>
              <h1 className="gameName">The Last of Us Part II</h1>
            </div>
          </div>
        </section>

        <section className="topSellers ourTeam">
  <h2>Discover Top Games</h2>
  <div className="cardsContainer overWrite">
    <div className="awardGames">
      <img
        src="/Images/Games/Game1.webp"
        alt="Elden Ring"
        className="image"
      />
      <p>Game of the Year Edition</p>
      <h1>Elden Ring</h1>
      <p className="price">$59.99</p>
    </div>
    <div className="awardGames">
      <img
        src="/Images/Games/Game2.webp"
        alt="Cyberpunk 2077"
        className="image"
      />
      <p>Phantom Liberty Bundle</p>
      <h1>Cyberpunk 2077</h1>
      <p className="price">$79.99</p>
    </div>
    <div className="awardGames">
      <img
        src="/Images/Games/Game3.webp"
        alt="God of War"
        className="image"
      />
      <p>Deluxe Edition</p>
      <h1>God of War</h1>
      <p className="price">$49.99</p>
    </div>
    <div className="awardGames">
      <img
        src="/Images/Games/Game4.webp"
        alt="Hogwarts Legacy"
        className="image"
      />
      <p>Collector's Edition</p>
      <h1>Hogwarts Legacy</h1>
      <p className="price">$89.99</p>
    </div>
    <div className="awardGames">
      <img
        src="/Images/Games/Game5.webp"
        alt="Assassin's Creed Valhalla"
        className="image"
      />
      <p>Ultimate Edition</p>
      <h1>Assassin's Creed Valhalla</h1>
      <p className="price">$69.99</p>
    </div>
    <div className="awardGames">
      <img
        src="/Images/Games/Game6.webp"
        alt="The Witcher 3"
        className="image"
      />
      <p>Complete Edition</p>
      <h1>The Witcher 3: Wild Hunt</h1>
      <p className="price">$39.99</p>
    </div>
    <div className="awardGames">
      <img
        src="/Images/Games/Game7.webp"
        alt="Red Dead Redemption 2"
        className="image"
      />
      <p>Special Edition</p>
      <h1>Red Dead Redemption 2</h1>
      <p className="price">$59.99</p>
    </div>
    <div className="awardGames">
      <img
        src="/Images/Games/Game8.webp"
        alt="Call of Duty: Modern Warfare II"
        className="image"
      />
      <p>Vault Edition</p>
      <h1>Call of Duty: Modern Warfare II</h1>
      <p className="price">$69.99</p>
    </div>
  </div>
</section>

      </main>
    </div>
  );
};

export default HomePage;
