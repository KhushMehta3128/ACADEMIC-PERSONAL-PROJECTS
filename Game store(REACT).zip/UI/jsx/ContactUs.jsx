import React from "react";

const ContactUs = () => {
  return (
    <div>
      {/* Khush */}
      <section className="Contect-Container">
        <div className="formContent">
          <h2>Get in Touch</h2>
          <p>
            Have a question or feedback for us? Fill out the form below, and
            we'll get back to you as soon as possible. Your input helps us serve
            you better.
          </p>
          <form action="/submit_form" method="POST">
            <label className="font" htmlFor="name">
              Name:
            </label>
            <input type="text" id="name" name="name" />
            <label className="font" htmlFor="email">
              Email:
            </label>
            <input type="email" id="email" name="email" />
            <label className="font" htmlFor="message">
              Message:
            </label>
            <textarea id="message" name="message" rows="4"></textarea>
            <button type="submit">Submit</button>
          </form>
        </div>
        <div className="mapContent">
          <h2>Visit Us</h2>
          <p>
            <strong>Address:</strong> 60, King St
            <br />
            <strong>Phone:</strong> 123,123,1234
            <br />
            <strong>Email:</strong> EpicGames@gmail.com
            <br />
            <strong>Business Hours:</strong> 9:00 AM - 10 PM
          </p>
          <img src="Images/Games/Screenshot.png" alt="Map Screenshot" width="500" height="450" />
        </div>
      </section>
    </div>
  );
};

export default ContactUs;
