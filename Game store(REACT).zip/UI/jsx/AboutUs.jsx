import React from "react";

const AboutUs = () => {
    return (
        <>
        {/* Khush */}
            <main className="main-container">
                <section className="messageCeo">
                    <h1>
                        About Epic Games - Creating Large ESport Community
                    </h1>

                    <div className="ceo-image-div">
                        <img src="/Images/Games/CEO.jpg" alt="CEO" />
                    </div>
                    <div className="ceo-message-div ceo_card">
                        <h1>Our Story</h1>
                        <p>
                            Epic Games was founded in 1991 by Tim Sweeney under the name "Potomac Computer Systems." The company initially focused on creating video games but quickly transitioned to developing game engines, with the launch of Unreal Engine in 1998 being a pivotal moment in its history. Over the years, Epic Games became a leader in the gaming industry, known for its groundbreaking titles like Unreal Tournament, Gears of War, and Fortnite, while also revolutionizing game development with its cutting-edge technology.
                        </p>
                    </div>
                </section>
                <hr />
                <section className="about">
                    <div className="ceo-message-div ceo_card">
                        <h1>Our Mission</h1>
                        <p>
                        Epic Games aims to build the most powerful and accessible tools for developers and creators worldwide. We are dedicated to pushing the boundaries of interactive entertainment and empowering creators to build stunning experiences that connect people across the globe. Our mission is to democratize game development, ensuring that everyone, from independent creators to major studios, can bring their visions to life with the Unreal Engine and other innovative technologies we provide.
                        </p>
                    </div>
                    <div className="ceo-message-div ceo_card">
                        <h1>Meet the Founders</h1>
                        <p>
                       <b>Tim Sweeney – Founder and CEO</b><br></br>
                        Tim Sweeney is the visionary behind Epic Games. He started the company with a deep passion for technology and gaming, creating the Unreal Engine and guiding the company through its evolution into a global powerhouse in game development and entertainment. Under his leadership, Epic Games has become synonymous with innovation and excellence in the gaming world.
                        </p>
                    </div>
                </section>
            </main>
        </>
    );
};

export default AboutUs;
