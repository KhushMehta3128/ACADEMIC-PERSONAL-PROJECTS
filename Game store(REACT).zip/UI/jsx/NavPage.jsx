import React from 'react';
import PropTypes from 'prop-types';
import { Link, useLocation } from 'react-router-dom';

const NavPage = ({ title }) => {
  const location = useLocation();

  return (
    <header className="simple-nav-header">
      <h1 className="simple-nav-title">{title}</h1>
      <nav>
        <ul className="simple-nav-list">
          <li className="simple-nav-item">
            <Link
              className={`simple-nav-link ${location.pathname === '/' ? 'active' : ''}`}
              to="/"
            >
              Home
            </Link>
          </li>
          <li className="simple-nav-item">
            <Link
              className={`simple-nav-link ${location.pathname === '/Products' ? 'active' : ''}`}
              to="/Products"
            >
              Products
            </Link>
          </li>
          <li className="simple-nav-item">
            <Link
              className={`simple-nav-link ${location.pathname === '/ContactUs' ? 'active' : ''}`}
              to="/ContactUs"
            >
              Contact Us
            </Link>
          </li>
          <li className="simple-nav-item">
            <Link
              className={`simple-nav-link ${location.pathname === '/AboutUs' ? 'active' : ''}`}
              to="/AboutUs"
            >
              About Us
            </Link>
          </li>
        </ul>
      </nav>
    </header>
  );
};

NavPage.propTypes = {
  title: PropTypes.string.isRequired,
};

export default NavPage;
