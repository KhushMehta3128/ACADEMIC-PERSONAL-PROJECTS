import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import NavPage from './NavPage.jsx';
import Footer from './Footer.jsx';
import 'bootstrap/dist/css/bootstrap.min.css';
import HomePage from './HomePage.jsx';
import Product from './Products.jsx';
import ContactUs from './ContactUs.jsx';
import AboutUs from './AboutUs.jsx';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../public/Css/styles.css';


// Main application component
const App = () => (
  <Router>
     <div className="d-flex flex-column min-vh-100">
      <NavPage title="Epic Games" />
      <main className="flex-grow-1">
        <Routes>
          <Route path="/" element={<HomePage />} />
        </Routes>
        <Routes>
          <Route path="/Products" element={<Product />} />
        </Routes>
        <Routes>
          <Route path="/ContactUs" element={<ContactUs />} />
        </Routes>
        <Routes>
          <Route path="/AboutUS" element={<AboutUs />} />
        </Routes>
      </main>
      <Footer />
    </div>
  </Router>
);

// to get the root container element
const container = document.getElementById('contents');
const root = createRoot(container);
root.render(<App />);
