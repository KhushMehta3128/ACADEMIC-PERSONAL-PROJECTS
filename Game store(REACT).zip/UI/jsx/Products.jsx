import React, { useState, useEffect, useCallback } from 'react';

const Product = () => {
  // slider images
    const [sliderIndex, setSliderIndex] = useState(0);
    const [colorIndex, setColorIndex] = useState(0);
    
    const slides = [
      {
          src: "/Images/Games/Game1.webp",
          alt: "Elden Ring"
      },
      {
          src: "/Images/Games/GhostOfTsushima.jpg",
          alt: "Ghost Of Tsushima"
      },
      {
          src: "/Images/Games/Lastofus.jpg",
          alt: "Last Of Us"
      },
      {
          src: "/Images/Games/RedDeadRedemption2.jpg",
          alt: "Red Dead Redemption 2"
      },
      {
          src: "/Images/Games/HorizonZeroDawn.jpg",
          alt: "Horizon Zero Dawn"
      },
      {
          src: "/Images/Games/AssassinsCreedValhalla.jpg",
          alt: "Assassin's Creed Valhalla"
      },
      {
          src: "/Images/Games/SpidermanMilesMorales.jpg",
          alt: "Spider-Man: Miles Morales"
      }
  ];
  // Slider code

    const nextSlide = useCallback(() => {
        setSliderIndex(prevIndex => (prevIndex + 1) % slides.length);
    }, [slides.length]);

    const changeBackgroundColor = useCallback(() => {
        setColorIndex(prevIndex => (prevIndex + 1) % slides.length);
    }, [slides.length]);

    useEffect(() => {
        const slideInterval = setInterval(nextSlide, 3000);
        const colorInterval = setInterval(changeBackgroundColor, 3000);

        return () => {
            clearInterval(slideInterval);
            clearInterval(colorInterval);
        };
    }, [nextSlide, changeBackgroundColor]);

    return (
        <div>
          {/* Swapnil Patel  */}
            <main>
                <section className="titleSec">
                    <div className="leftContent">
                        {slides.map((slide, index) => (
                            <div 
                                key={index}
                                className="image-description"
                                style={{
                                    backgroundColor: colorIndex === index ? 'rgba(255, 255, 255, 0.2)' : 'transparent'
                                }}
                            >
                                <div className="image">
                                    <img src={slide.src} alt={slide.alt} />
                                </div>
                                <p>{slide.alt}</p>
                                <div className="description"></div>
                            </div>
                        ))}
                    </div>
                    <div className="slider">
                        <div 
                            className="slider-inner"
                            style={{
                                transform: `translateX(-${sliderIndex * 100}%)`,
                                transition: 'transform 0.5s ease-in-out'
                            }}
                        >
                            {slides.map((slide, index) => (
                                <div key={index} className="slide">
                                    <img src={slide.src} alt={slide.alt} />
                                </div>
                            ))}
                        </div>
                    </div>
                </section>
                <section className="topSellers ourTeam">
        <h2>Budget-Friendly Games</h2>
        <div className="cardsContainer overWrite">
          <div className="awardGames">
            <img
              src="/Images/Games/minecraft.webp"
              alt="Minecraft"
              className="image"
            />
            <p>Base Game</p>
            <h1>Minecraft</h1>
            <p className="price">$26.95</p>
          </div>
          <div className="awardGames">
            <img
              src="/Images/Games/stardew-valley.webp"
              alt="Stardew Valley"
              className="image"
            />
            <p>Base Game</p>
            <h1>Stardew Valley</h1>
            <p className="price">$14.99</p>
          </div>
          <div className="awardGames">
            <img
              src="/Images/Games/hollow-knight.webp"
              alt="Hollow Knight"
              className="image"
            />
            <p>Base Game</p>
            <h1>Hollow Knight</h1>
            <p className="price">$15.99</p>
          </div>
          <div className="awardGames">
            <img
              src="/Images/Games/terraria.webp"
              alt="Terraria"
              className="image"
            />
            <p>Complete Edition</p>
            <h1>Terraria</h1>
            <p className="price">$9.99</p>
          </div>
          <div className="awardGames">
            <img
              src="/Images/Games/among-us.webp"
              alt="Among Us"
              className="image"
            />
            <p>Base Game</p>
            <h1>Among Us</h1>
            <p className="price">$4.99</p>
          </div>
          <div className="awardGames">
            <img
              src="/Images/Games/vampire-survivors.webp"
              alt="Vampire Survivors"
              className="image"
            />
            <p>Base Game</p>
            <h1>Vampire Survivors</h1>
            <p className="price">$4.99</p>
          </div>
          <div className="awardGames">
            <img
              src="/Images/Games/undertale.webp"
              alt="Undertale"
              className="image"
            />
            <p>Base Game</p>
            <h1>Undertale</h1>
            <p className="price">$9.99</p>
          </div>
          <div className="awardGames">
            <img
              src="/Images/Games/portal.webp"
              alt="Portal"
              className="image"
            />
            <p>Base Game</p>
            <h1>Portal</h1>
            <p className="price">$9.99</p>
          </div>
        </div>
      </section>
      
      <section className="topSellers ourTeam">
        <h2>Award-Winning Games</h2>
        <div className="cardsContainer overWrite">
          <div className="awardGames">
            <img
              src="/Images/Games/elden-ring.webp"
              alt="Elden Ring"
              className="image"
            />
            <p>Game of the Year Edition</p>
            <h1>Elden Ring</h1>
            <p className="price">$59.99</p>
          </div>
          <div className="awardGames">
            <img
              src="/Images/Games/Game3.webp"
              alt="God of War"
              className="image"
            />
            <p>Complete Edition</p>
            <h1>God of War</h1>
            <p className="price">$49.99</p>
          </div>
          <div className="awardGames">
            <img
              src="/Images/Games/zelda-botw.webp"
              alt="The Legend of Zelda: Breath of the Wild"
              className="image"
            />
            <p>Base Game</p>
            <h1>Breath of the Wild</h1>
            <p className="price">$59.99</p>
          </div>
          <div className="awardGames">
            <img
              src="/Images/Games/Game7.webp"
              alt="Red Dead Redemption 2"
              className="image"
            />
            <p>Ultimate Edition</p>
            <h1>Red Dead Redemption 2</h1>
            <p className="price">$59.99</p>
          </div>
          <div className="awardGames">
            <img
              src="/Images/Games/Game6.webp"
              alt="The Witcher 3"
              className="image"
            />
            <p>GOTY Edition</p>
            <h1>The Witcher 3</h1>
            <p className="price">$39.99</p>
          </div>
          <div className="awardGames">
            <img
              src="/Images/Games/hades.webp"
              alt="Hades"
              className="image"
            />
            <p>Base Game</p>
            <h1>Hades</h1>
            <p className="price">$24.99</p>
          </div>
          <div className="awardGames">
            <img
              src="/Images/Games/disco-elysium.webp"
              alt="Disco Elysium"
              className="image"
            />
            <p>Final Cut</p>
            <h1>Disco Elysium</h1>
            <p className="price">$39.99</p>
          </div>
          <div className="awardGames">
            <img
              src="/Images/Games/ghost-tsushima.webp"
              alt="Ghost of Tsushima"
              className="image"
            />
            <p>Director's Cut</p>
            <h1>Ghost of Tsushima</h1>
            <p className="price">$49.99</p>
          </div>
        </div>
      </section>
            </main>
        </div>
    );
};

export default Product;