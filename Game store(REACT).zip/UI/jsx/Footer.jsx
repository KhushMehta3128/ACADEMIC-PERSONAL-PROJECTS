import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const Footer = () => {
  return (
    <footer className="custom-footer">
      <p className="copyright">&copy; 2024 Your Company. All rights reserved.</p>
    </footer>
  );
};

export default Footer;
