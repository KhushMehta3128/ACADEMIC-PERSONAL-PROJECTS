const express = require("express");
const path = require("path");
const helmet = require("helmet"); // Security middleware

const app = express();
const publicPath = path.resolve(__dirname, '../public');

// Helmet to enhance your API's security
app.use(helmet());

// Serve static files from the public directory
app.use(express.static(publicPath));

// Serve the React app for any route
app.get('*', (req, res) => {
  res.sendFile(path.resolve(publicPath, 'index.html'));
});

const port = process.env.UI_PORT || 5000;
app.listen(port, () => {
  console.log(`UI started on port http://localhost:${port}`);
}).on('error', (err) => {
  console.error(`Failed to start server: ${err.message}`);
});